
import 'dotenv/config'; // Carrega variáveis de ambiente do arquivo .env
import express from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import cluster from 'cluster';
import os from 'os';
import compression from 'compression';
import helmet from 'helmet';
import multer from 'multer';
import rateLimit from 'express-rate-limit';
import fs from 'fs';
import { dbManager } from './backend/databaseManager.js';

// Configuração de Caminhos
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = process.env.PORT || 3000;
const numCPUs = process.env.WEB_CONCURRENCY || (process.env.NODE_ENV === 'production' ? os.cpus().length : 1);
const ADMIN_API_KEY = process.env.ADMIN_API_KEY || "flux_admin_secret_key_123";

const SYNCPAY_API_URL = 'https://api.syncpayments.com.br';

// --- DIAGNÓSTICO DE FIOS SOLTOS (WIRES CHECK) ---
const runDiagnostics = () => {
    const missing = [];
    if (!process.env.DATABASE_URL && !process.env.DOCKER_ENV) missing.push("PostgreSQL (DATABASE_URL) - Site: supabase.com");
    if (!process.env.SCYLLA_HOST && !process.env.DOCKER_ENV) missing.push("ScyllaDB (SCYLLA_HOST) - Site: scylladb.com");
    if (!process.env.REDIS_URL && !process.env.DOCKER_ENV) missing.push("Redis (REDIS_URL) - Site: upstash.com");
    if (!process.env.GOOGLE_CLIENT_ID) missing.push("Google Auth (CLIENT_ID) - Site: console.cloud.google.com");
    
    console.log('\n🔌 --- STATUS DA CONEXÃO (100k Users Ready) ---');
    if (missing.length === 0) {
        console.log('✅ Todos os serviços externos configurados ou rodando via Docker.');
    } else {
        console.log('⚠️  MODO DESENVOLVIMENTO/FALLBACK ATIVO.');
        console.log('   Para produção (100k users), conecte os seguintes serviços:');
        missing.forEach(m => console.log(`   ❌ Faltando: ${m}`));
    }
    console.log('--------------------------------------------------\n');
};

// Configuração de Pasta de Uploads Segura
const uploadDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
}

// 🛡️ FILTRO DE ARQUIVOS RIGOROSO
const fileFilter = (req, file, cb) => {
    const allowedMimes = {
        'image/jpeg': ['.jpg', '.jpeg'],
        'image/png': ['.png'],
        'image/gif': ['.gif'],
        'image/webp': ['.webp'],
        'video/mp4': ['.mp4'],
        'video/webm': ['.webm'],
        'video/quicktime': ['.mov']
    };

    const mime = file.mimetype;
    const ext = path.extname(file.originalname).toLowerCase();

    if (allowedMimes[mime] && allowedMimes[mime].includes(ext)) {
        cb(null, true);
    } else {
        cb(new Error('Arquivo inválido: Tipo de arquivo ou extensão não permitida.'), false);
    }
};

const storage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, uploadDir),
    filename: (req, file, cb) => {
        const safeName = file.originalname.replace(/[^a-zA-Z0-9.]/g, '_');
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, uniqueSuffix + '-' + safeName);
    }
});

const upload = multer({ 
    storage: storage, 
    fileFilter: fileFilter,
    limits: { fileSize: 50 * 1024 * 1024 } // Limite de 50MB
});

// Inicializar Conexões de Banco (Async) - Non-blocking
dbManager.init().catch(err => console.warn("DB Init Warning (Server will run in fallback mode):", err.message));

if (cluster.isPrimary && numCPUs > 1) {
    console.log(`🚀 Flux Master ${process.pid} running with ${numCPUs} workers`);
    runDiagnostics();
    for (let i = 0; i < numCPUs; i++) cluster.fork();
    cluster.on('exit', (worker) => {
        console.log(`Worker ${worker.process.pid} died. Replacing...`);
        cluster.fork();
    });
} else {
    const app = express();

    // --- SECURITY MIDDLEWARES ---
    app.set('trust proxy', 1); 
    
    const limiter = rateLimit({
        windowMs: 15 * 60 * 1000,
        max: 5000, // Increased limit for real-time polling
        standardHeaders: true,
        legacyHeaders: false,
        message: { error: "Muitas requisições, tente novamente mais tarde." }
    });
    app.use(limiter);

    app.use(helmet({
        contentSecurityPolicy: {
            directives: {
                defaultSrc: ["'self'"],
                scriptSrc: ["'self'", "'unsafe-inline'", "https://accounts.google.com", "https://cdnjs.cloudflare.com", "https://cdn.tailwindcss.com"],
                styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com", "https://cdnjs.cloudflare.com"], 
                imgSrc: ["'self'", "data:", "https:", "blob:", "https://*.googleusercontent.com"],
                connectSrc: ["'self'", "https://accounts.google.com", "https://api.syncpayments.com.br", "https://ipapi.co", "https://ipwho.is", "http://localhost:3000", "https://*.ngrok-free.app", "https://www.googleapis.com"],
                fontSrc: ["'self'", "https://fonts.gstatic.com", "https://cdnjs.cloudflare.com"],
                frameSrc: ["'self'", "https://accounts.google.com"],
                objectSrc: ["'none'"],
                upgradeInsecureRequests: [],
            },
        },
        crossOriginEmbedderPolicy: false,
        crossOriginResourcePolicy: { policy: "cross-origin" },
        referrerPolicy: { policy: "strict-origin-when-cross-origin" },
        xContentTypeOptions: true
    }));

    app.use(compression()); 
    
    app.use(cors({ 
        origin: (origin, callback) => callback(null, true),
        credentials: true,
        methods: ['GET', 'POST', 'PUT', 'DELETE']
    }));
    
    app.use(express.json({ limit: '50kb' })); 

    app.get('/health', (req, res) => res.status(200).json({ 
        status: 'ok', 
        db: dbManager.state,
        uptime: process.uptime()
    }));

    app.use('/uploads', express.static(uploadDir, {
        maxAge: '30d',
        immutable: true,
        setHeaders: (res, path) => {
            res.setHeader('X-Content-Type-Options', 'nosniff');
        }
    }));

    // --- GLOBAL AUTH ROUTES ---
    app.post('/api/auth/register', async (req, res) => {
        try {
            const { email, password, profile } = req.body;
            const user = await dbManager.auth.register(email, password, profile);
            res.status(201).json({ success: true, user });
        } catch (e) {
            res.status(400).json({ error: e.message });
        }
    });

    app.post('/api/auth/login', async (req, res) => {
        try {
            const { email, password } = req.body;
            const { user, token } = await dbManager.auth.login(email, password);
            res.json({ success: true, user, token });
        } catch (e) {
            res.status(401).json({ error: e.message });
        }
    });

    app.get('/api/users/me', async (req, res) => {
        const email = req.query.email; // In real app, extract from JWT
        if(!email) return res.status(401).json({error: "Unauthorized"});
        const user = await dbManager.auth.getUser(email);
        res.json(user || null);
    });

    app.put('/api/users/update', async (req, res) => {
        try {
            const { email, updates } = req.body;
            const updated = await dbManager.users.update(email, updates);
            res.json({ success: true, user: updated });
        } catch(e) {
            res.status(500).json({ error: e.message });
        }
    });

    app.get('/api/users/search', async (req, res) => {
        const query = req.query.q;
        const results = await dbManager.auth.searchUsers(query);
        res.json(results);
    });

    // --- GLOBAL POST ROUTES ---
    app.get('/api/posts', async (req, res) => {
        try {
            const limit = parseInt(req.query.limit) || 20;
            const cursor = req.query.cursor ? parseInt(req.query.cursor) : Date.now();
            let posts = await dbManager.posts.list(limit, cursor);
            
            // Populate "liked" state based on user email (Simple simulation)
            const viewerEmail = req.query.viewer;
            if (viewerEmail && posts.length > 0) {
                posts = posts.map(p => ({
                    ...p,
                    liked: p.likedBy?.includes(viewerEmail) || false
                }));
            }
            
            const nextCursor = posts.length > 0 ? posts[posts.length - 1].timestamp : null;
            res.json({ data: posts, nextCursor });
        } catch (e) {
            console.error(e);
            res.json({ data: [], nextCursor: null });
        }
    });

    app.post('/api/posts/create', async (req, res) => {
        const post = req.body;
        if (!post || !post.username) {
            return res.status(400).json({ error: "Dados inválidos" });
        }
        const created = await dbManager.posts.create(post);
        res.status(201).json({ success: true, post: created });
    });

    app.post('/api/posts/like', async (req, res) => {
        const { postId, userEmail } = req.body;
        const updatedPost = await dbManager.posts.toggleLike(postId, userEmail);
        res.json({ success: !!updatedPost, post: updatedPost });
    });

    app.post('/api/posts/comment', async (req, res) => {
        const { postId, comment } = req.body;
        const savedComment = await dbManager.posts.addComment(postId, comment);
        res.json({ success: !!savedComment, comment: savedComment });
    });

    // --- GLOBAL GROUP ROUTES ---
    app.get('/api/groups', async (req, res) => {
        const groups = await dbManager.groups.list();
        res.json({ data: groups });
    });

    app.post('/api/groups/create', async (req, res) => {
        await dbManager.groups.create(req.body);
        res.status(201).json({ success: true });
    });

    // --- UPLOAD ---
    app.post('/api/upload', upload.array('file', 5), (req, res) => {
        if (!req.files?.length) return res.status(400).json({ error: 'Nenhum arquivo válido enviado.' });
        const urls = req.files.map(f => ({
            url: `/uploads/${f.filename}`,
            type: f.mimetype
        }));
        res.json({ success: true, files: urls });
    });

    app.use((err, req, res, next) => {
        if (err instanceof multer.MulterError) {
            return res.status(400).json({ error: `Erro de Upload: ${err.message}` });
        } else if (err) {
            return res.status(400).json({ error: err.message });
        }
        next();
    });

    // --- PROXY ---
    const proxyToSyncPay = async (endpoint, method, body, res) => {
        try {
            const url = `${SYNCPAY_API_URL}${endpoint}`;
            const options = {
                method: method,
                headers: { 
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                }
            };
            if (body) options.body = JSON.stringify(body);
            const response = await fetch(url, options);
            let data = {};
            try { data = await response.json(); } catch (e) {}
            res.status(response.status).json(data);
        } catch (error) {
            res.status(502).json({ error: "Erro de gateway de pagamento." });
        }
    };

    app.get('/api/syncpay/fees', (req, res) => proxyToSyncPay('/fees', 'GET', null, res));
    app.post('/api/syncpay/auth-token', (req, res) => proxyToSyncPay('/auth/token', 'POST', req.body, res));
    app.post('/api/syncpay/balance', (req, res) => proxyToSyncPay('/balance', 'POST', req.body, res));
    app.post('/api/syncpay/transactions', (req, res) => proxyToSyncPay('/transactions', 'POST', req.body, res));
    app.post('/api/syncpay/cash-in', (req, res) => proxyToSyncPay('/cash-in', 'POST', req.body, res));
    app.post('/api/syncpay/cash-out', (req, res) => proxyToSyncPay('/cash-out', 'POST', req.body, res));
    app.post('/api/syncpay/check-status', (req, res) => proxyToSyncPay('/transactions/status', 'POST', req.body, res));

    // Fallback Frontend
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
        if (!req.path.startsWith('/api')) {
            if (fs.existsSync(path.join(distPath, 'index.html'))) {
                res.sendFile(path.join(distPath, 'index.html'));
            } else {
                res.status(404).send("Flux Platform API Running.");
            }
        } else res.status(404).json({ error: 'Not Found' });
    });

    if (numCPUs === 1) {
        runDiagnostics(); // Run diagnostics if single process
    }

    app.listen(PORT, '0.0.0.0', () => {
        console.log(`🚀 Flux Global Server running on port ${PORT}`);
    });
}
