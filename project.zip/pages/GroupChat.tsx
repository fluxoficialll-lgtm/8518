
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { groupService } from '../services/groupService';
import { chatService } from '../services/chatService'; 
import { authService } from '../services/authService';
import { db } from '@/database';
import { Group, ChatMessage } from '../types';

export const GroupChat: React.FC = () => {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const [group, setGroup] = useState<Group | null>(null);
  
  // Permission States
  const [isCreator, setIsCreator] = useState(false);
  const [canPost, setCanPost] = useState(true);
  
  // Messages State
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  // Search State
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Media Gallery State
  const [isGalleryOpen, setIsGalleryOpen] = useState(false);
  const [galleryTab, setGalleryTab] = useState<'all' | 'image' | 'video'>('all');
  const [galleryViewerIndex, setGalleryViewerIndex] = useState<number | null>(null);

  // Slow Mode State
  const [cooldown, setCooldown] = useState(0);
  const [maxCooldown, setMaxCooldown] = useState(0); 

  // Audio Recording
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const recordingInterval = useRef<any>(null);

  // Audio Playback
  const [playingAudioId, setPlayingAudioId] = useState<number | null>(null);
  const audioTimeoutRef = useRef<any>(null);

  // Zoom Media (For Chat Timeline)
  const [zoomedMedia, setZoomedMedia] = useState<{ url: string, type: 'image' | 'video' } | null>(null);

  // Media Preview (Upload)
  const [mediaPreview, setMediaPreview] = useState<{ file: File, url: string, type: 'image' | 'video' | 'file' } | null>(null);
  const [mediaCaption, setMediaCaption] = useState('');

  const menuRef = useRef<HTMLDivElement>(null);
  const buttonRef = useRef<HTMLButtonElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const docInputRef = useRef<HTMLInputElement>(null);

  const currentUserEmail = authService.getCurrentUserEmail();

  // Load Group and Messages
  useEffect(() => {
      if (id) {
          const loadedGroup = groupService.getGroupById(id);

          if (loadedGroup) {
              setGroup(loadedGroup);
              const isOwner = loadedGroup.creatorEmail === currentUserEmail;
              const isAdmin = isOwner || (currentUserEmail && loadedGroup.admins?.includes(currentUserEmail));
              
              setIsCreator(isOwner);

              if (isAdmin) {
                  setCanPost(true);
              } else {
                  setCanPost(!loadedGroup.settings?.onlyAdminsPost);
              }

              // VIP Check
              if (loadedGroup.isVip && !isOwner && currentUserEmail) {
                  const hasAccess = db.vipAccess.check(currentUserEmail, loadedGroup.id);
                  if (!hasAccess) {
                      navigate(`/vip-group-sales/${loadedGroup.id}`, { replace: true });
                      return;
                  }
              }
              
              loadMessages();
              chatService.markChatAsRead(id);

          } else {
              navigate('/groups');
          }
      }
  }, [id, navigate]);

  const loadMessages = () => {
      if (!id) return;
      const chatData = chatService.getChat(id);
      setMessages(chatData.messages || []);
  };

  // Real Time Subscription
  useEffect(() => {
      const unsubscribe = db.subscribe('chats', () => {
          loadMessages();
      });
      const unsubscribeGroup = db.subscribe('groups', () => {
          if (id) {
              const updatedGroup = groupService.getGroupById(id);
              if (updatedGroup) {
                  const isOwner = updatedGroup.creatorEmail === currentUserEmail;
                  const isAdmin = isOwner || (currentUserEmail && updatedGroup.admins?.includes(currentUserEmail));
                  if (isAdmin) setCanPost(true);
                  else setCanPost(!updatedGroup.settings?.onlyAdminsPost);
              }
          }
      });

      return () => { unsubscribe(); unsubscribeGroup(); };
  }, [id]);

  // Derived Media Lists for Gallery
  const allMedia = useMemo(() => {
      return messages.filter(m => (m.contentType === 'image' || m.contentType === 'video') && m.mediaUrl).reverse();
  }, [messages]);

  const photos = useMemo(() => allMedia.filter(m => m.contentType === 'image'), [allMedia]);
  const videos = useMemo(() => allMedia.filter(m => m.contentType === 'video'), [allMedia]);

  const currentGalleryItems = useMemo(() => {
      if (galleryTab === 'image') return photos;
      if (galleryTab === 'video') return videos;
      return allMedia;
  }, [galleryTab, allMedia, photos, videos]);

  // Filtered Messages for Search
  const displayMessages = useMemo(() => {
      if (!searchQuery) return messages;
      return messages.filter(m => m.text && m.text.toLowerCase().includes(searchQuery.toLowerCase()));
  }, [messages, searchQuery]);

  // Slow Mode Logic
  useEffect(() => {
      if (group?.settings?.msgSlowMode && !isCreator && currentUserEmail) {
          const interval = group.settings.msgSlowModeInterval || 30;
          const myLastMsg = [...messages].reverse().find(m => m.senderEmail === currentUserEmail);
          
          if (myLastMsg) {
              const now = Date.now();
              const elapsedSeconds = (now - myLastMsg.id) / 1000;
              
              if (elapsedSeconds < interval) {
                  const remaining = Math.ceil(interval - elapsedSeconds);
                  setCooldown(remaining);
                  setMaxCooldown(interval);
              }
          }
      }
  }, [messages, group, isCreator, currentUserEmail]);

  useEffect(() => {
      if (cooldown <= 0) return;
      const timer = setInterval(() => {
          setCooldown(prev => {
              if (prev <= 1) return 0;
              return prev - 1;
          });
      }, 1000);
      return () => clearInterval(timer);
  }, [cooldown]);

  useEffect(() => {
      const handleClickOutside = (event: MouseEvent) => {
          if (menuRef.current && !menuRef.current.contains(event.target as Node) && 
              buttonRef.current && !buttonRef.current.contains(event.target as Node)) {
              setIsMenuOpen(false);
          }
      };
      document.addEventListener('mousedown', handleClickOutside);
      return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
      if (!isSearchOpen && !isGalleryOpen) {
          messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
      }
  }, [messages.length, isRecording, isSearchOpen, isGalleryOpen]);

  useEffect(() => {
      if (isRecording) {
          recordingInterval.current = setInterval(() => {
              setRecordingTime(prev => prev + 1);
          }, 1000);
      } else {
          clearInterval(recordingInterval.current);
          setRecordingTime(0);
      }
      return () => clearInterval(recordingInterval.current);
  }, [isRecording]);

  const getCurrentUserInfo = () => {
      const user = authService.getCurrentUser();
      return {
          name: user?.profile?.nickname || user?.profile?.name || 'Você',
          avatar: user?.profile?.photoUrl,
          email: user?.email
      };
  };

  const saveMessage = (msg: ChatMessage) => {
      if (!id) return;
      chatService.sendMessage(id, msg);
  };

  const handleSendMessage = () => {
      if (cooldown > 0) return; 
      if (inputText.trim()) {
          const userInfo = getCurrentUserInfo();
          const newMessage: ChatMessage = {
              id: Date.now(),
              senderName: userInfo.name,
              senderAvatar: userInfo.avatar,
              senderEmail: userInfo.email,
              text: inputText,
              type: 'sent',
              contentType: 'text',
              timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
              status: 'sent'
          };
          saveMessage(newMessage);
          setInputText('');
      }
  };

  const handleAttachmentClick = () => { if (cooldown > 0) return; fileInputRef.current?.click(); };
  const handleDocClick = () => { if (cooldown > 0) return; docInputRef.current?.click(); };
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, isDoc: boolean = false) => {
      const file = e.target.files?.[0];
      if (!file) return;
      const url = URL.createObjectURL(file);
      let type: 'image' | 'video' | 'file' = 'file';
      if (!isDoc) { type = file.type.startsWith('video/') ? 'video' : 'image'; } else { type = 'file'; }
      setMediaPreview({ file, url, type });
      setMediaCaption('');
      if (fileInputRef.current) fileInputRef.current.value = '';
      if (docInputRef.current) docInputRef.current.value = '';
  };
  const handleSendMedia = () => {
      if (!mediaPreview || cooldown > 0) return;
      const reader = new FileReader();
      reader.onload = (ev) => {
          const base64 = ev.target?.result as string;
          const userInfo = getCurrentUserInfo();
          let text = mediaCaption.trim();
          if (!text) { if (mediaPreview.type === 'video') text = 'Vídeo'; else if (mediaPreview.type === 'image') text = 'Foto'; else text = 'Arquivo'; }
          const newMessage: ChatMessage = {
              id: Date.now(),
              senderName: userInfo.name,
              senderAvatar: userInfo.avatar,
              senderEmail: userInfo.email,
              text: text,
              type: 'sent',
              contentType: mediaPreview.type,
              mediaUrl: base64,
              fileName: mediaPreview.type === 'file' ? mediaPreview.file.name : undefined,
              timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
              status: 'sent'
          };
          saveMessage(newMessage);
          setMediaPreview(null);
          setMediaCaption('');
      };
      reader.readAsDataURL(mediaPreview.file);
  };
  const handleAudioAction = () => {
      if (cooldown > 0) return;
      if (inputText.length > 0) { handleSendMessage(); } else {
          if (isRecording) {
              setIsRecording(false);
              const userInfo = getCurrentUserInfo();
              const durationStr = formatTime(recordingTime);
              const newMessage: ChatMessage = {
                  id: Date.now(),
                  senderName: userInfo.name,
                  senderAvatar: userInfo.avatar,
                  senderEmail: userInfo.email,
                  text: 'Mensagem de Voz',
                  type: 'sent',
                  contentType: 'audio',
                  duration: durationStr,
                  timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                  status: 'sent'
              };
              saveMessage(newMessage);
          } else { setIsRecording(true); }
      }
  };
  const cancelRecording = () => { setIsRecording(false); };
  const handlePlayAudio = (id: number, durationStr?: string) => {
      if (playingAudioId === id) {
          setPlayingAudioId(null);
          if (audioTimeoutRef.current) clearTimeout(audioTimeoutRef.current);
      } else {
          setPlayingAudioId(id);
          let durationMs = 3000; 
          if (durationStr) {
              const parts = durationStr.split(':');
              if (parts.length === 2) { const min = parseInt(parts[0]); const sec = parseInt(parts[1]); durationMs = (min * 60 + sec) * 1000; }
          }
          if (audioTimeoutRef.current) clearTimeout(audioTimeoutRef.current);
          audioTimeoutRef.current = setTimeout(() => { setPlayingAudioId(null); }, durationMs);
      }
  };
  const formatTime = (seconds: number) => { const mins = Math.floor(seconds / 60); const secs = seconds % 60; return `${mins}:${secs < 10 ? '0' : ''}${secs}`; };
  const handleCopyGroupLink = () => {
      if (!id) return;
      const link = group?.isVip ? `${window.location.origin}/#/vip-group-sales/${id}` : `${window.location.origin}/#/group-landing/${id}`;
      navigator.clipboard.writeText(link).then(() => { alert('Link do grupo copiado!'); });
      setIsMenuOpen(false);
  };

  const getGroupCover = () => {
      if (group?.coverImage) return <img src={group.coverImage} alt="Group" style={{width: '100%', height: '100%', objectFit: 'cover'}} />;
      return <i className="fa-solid fa-users" style={{fontSize: '16px'}}></i>;
  };

  const renderStatusIcon = (status: string) => {
      if (status === 'sent') return <i className="fa-solid fa-check" style={{ color: 'rgba(255,255,255,0.6)' }}></i>; 
      if (status === 'delivered') return <i className="fa-solid fa-check-double" style={{ color: 'rgba(255,255,255,0.6)' }}></i>; 
      if (status === 'read') return <i className="fa-solid fa-check-double" style={{ color: '#00c2ff' }}></i>; 
      return null;
  };

  return (
    <div className="h-[100dvh] flex flex-col overflow-hidden" style={{ background: 'radial-gradient(circle at top left, #0c0f14, #0a0c10)', color: '#fff', fontFamily: "'Roboto', sans-serif", fontWeight: 500, textShadow: '0 0 3px rgba(0, 194, 255, 0.1)' }}>
      <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet" />
      <style>{`
        /* Slow Mode & Input Styles from original */
        .slow-mode-container {
            flex-grow: 1; display: flex; align-items: center; justify-content: center;
            background: rgba(255, 215, 0, 0.05); border: 1px solid rgba(255, 215, 0, 0.3);
            border-radius: 12px; padding: 8px; margin: 0 8px; position: relative; overflow: hidden;
        }
        .slow-mode-progress {
            position: absolute; left: 0; top: 0; height: 100%; background: rgba(255, 215, 0, 0.1);
            transition: width 1s linear; z-index: 0;
        }
        .slow-mode-content { z-index: 1; display: flex; align-items: center; gap: 10px; font-size: 13px; color: #FFD700; font-weight: 600; }
        .slow-mode-icon { animation: pulse 1.5s infinite; }
        @keyframes pulse { 0% { opacity: 0.6; } 50% { opacity: 1; } 100% { opacity: 0.6; } }
        .restricted-input-area {
            position: fixed; bottom: 0; width: 100%; background: #1a1e26;
            padding: 15px; border-top: 1px solid rgba(255,255,255,0.1); z-index: 15;
            display: flex; align-items: center; justify-content: center;
            color: #aaa; font-size: 13px; font-weight: 600; gap: 8px;
        }

        /* Gallery Modal Styles */
        .gallery-modal-overlay {
            position: fixed; top: 0; left: 0; width: 100%; height: 100%;
            background: #000; z-index: 100; display: flex; flex-direction: column;
            animation: slideUp 0.3s ease-out;
        }
        .gallery-header {
            display: flex; align-items: center; justify-content: space-between;
            padding: 15px 20px; border-bottom: 1px solid rgba(255,255,255,0.1);
            background: #0c0f14;
        }
        .gallery-tabs {
            display: flex; justify-content: center; gap: 10px; padding: 10px;
            background: #0c0f14;
        }
        .gallery-tab {
            padding: 8px 16px; border-radius: 20px; font-size: 13px;
            background: rgba(255,255,255,0.05); color: #888; border: 1px solid transparent;
            cursor: pointer; transition: 0.2s;
        }
        .gallery-tab.active {
            background: rgba(0,194,255,0.1); color: #00c2ff; border-color: #00c2ff; font-weight: 700;
        }
        .gallery-grid {
            flex-grow: 1; overflow-y: auto; padding: 1px;
            display: grid; grid-template-columns: repeat(3, 1fr); gap: 2px;
            align-content: start;
        }
        .gallery-item {
            position: relative; aspect-ratio: 1; background: #111; cursor: pointer;
        }
        .gallery-item img, .gallery-item video {
            width: 100%; height: 100%; object-fit: cover;
        }
        .video-indicator {
            position: absolute; bottom: 5px; left: 5px; color: #fff; font-size: 12px;
            text-shadow: 0 1px 2px rgba(0,0,0,0.8);
        }
        @keyframes slideUp { from { transform: translateY(100%); } to { transform: translateY(0); } }
      `}</style>
      
      {/* HEADER */}
      <header style={{
        display:'flex', alignItems:'center', padding:'12px 16px',
        background: '#0c0f14', position:'fixed', width:'100%', zIndex:10, 
        borderBottom:'1px solid rgba(255,255,255,0.1)', top: 0, height: '60px'
      }}>
          <button className="back-button" onClick={() => navigate('/groups')} style={{background:'none', border:'none', color:'#00c2ff', fontSize:'18px', cursor:'pointer', padding: '0 10px'}}>
              <i className="fa-solid fa-arrow-left"></i>
          </button>
          
          {isSearchOpen ? (
              <div style={{flexGrow: 1, display: 'flex', alignItems: 'center', background: 'rgba(255,255,255,0.1)', borderRadius: '20px', padding: '0 10px', marginRight: '10px'}}>
                  <i className="fa-solid fa-magnifying-glass" style={{color: '#aaa', fontSize: '14px'}}></i>
                  <input 
                    autoFocus
                    type="text" 
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Buscar na conversa..."
                    style={{background: 'transparent', border: 'none', color: '#fff', padding: '8px', outline: 'none', width: '100%', fontSize: '14px'}}
                  />
                  <i className="fa-solid fa-xmark" style={{color: '#aaa', cursor: 'pointer', padding: '5px'}} onClick={() => { setIsSearchOpen(false); setSearchQuery(''); }}></i>
              </div>
          ) : (
              <div className="chat-info" style={{display: 'flex', alignItems: 'center', flexGrow: 1, marginLeft: '10px'}}>
                  <div className="chat-avatar" style={{
                      width: '36px', height: '36px', borderRadius: '50%', 
                      background: '#1e2531', display: 'flex', justifyContent: 'center', alignItems: 'center',
                      border: '1px solid #00c2ff', marginRight: '10px', overflow: 'hidden', color: '#00c2ff'
                  }}>
                      {getGroupCover()}
                  </div>
                  <div className="chat-details">
                      <h2 style={{fontSize: '16px', color: '#fff', lineHeight: 1.2, fontWeight: 700}}>{group?.name || 'Carregando...'}</h2>
                      <p style={{fontSize: '12px', color: '#00c2ff', opacity: 0.8, fontWeight: 500}}>{messages.length} mensagens</p>
                  </div>
              </div>
          )}

          <div style={{display: 'flex', gap: '15px', alignItems: 'center'}}>
              {!isSearchOpen && (
                  <>
                    <button onClick={() => setIsSearchOpen(true)} style={{background:'none', border:'none', color:'#00c2ff', fontSize:'18px', cursor:'pointer'}}>
                        <i className="fa-solid fa-magnifying-glass"></i>
                    </button>
                    <button onClick={() => setIsGalleryOpen(true)} style={{background:'none', border:'none', color:'#00c2ff', fontSize:'18px', cursor:'pointer'}}>
                        <i className="fa-solid fa-photo-film"></i>
                    </button>
                  </>
              )}
              <div className="options-container" style={{position: 'relative'}}>
                  <button 
                      ref={buttonRef}
                      className="options-button" 
                      onClick={() => setIsMenuOpen(!isMenuOpen)}
                      style={{background:'none', border:'none', color:'#00c2ff', fontSize:'20px', cursor:'pointer', padding: '0 5px'}}
                  >
                      <i className="fa-solid fa-ellipsis-vertical"></i>
                  </button>
                  
                  {isMenuOpen && (
                      <div className="dropdown-menu" ref={menuRef} style={{
                        position: 'absolute', top: '40px', right: 0,
                        background: '#1a1e26', border: '1px solid rgba(0, 194, 255, 0.2)',
                        borderRadius: '8px', boxShadow: '0 4px 12px rgba(0, 0, 0, 0.5)',
                        width: '180px', zIndex: 20, display: isMenuOpen ? 'block' : 'none', overflow: 'hidden'
                      }}>
                          <button onClick={handleCopyGroupLink} style={{display: 'flex', alignItems: 'center', padding: '12px 15px', color: '#fff', background: 'none', border: 'none', fontSize: '14px', cursor: 'pointer', textAlign: 'left', width: '100%', borderBottom: '1px solid rgba(255,255,255,0.05)'}}>
                              <i className="fa-solid fa-link" style={{marginRight: '10px', width: '20px', textAlign: 'center'}}></i> Copiar Link
                          </button>
                          <button onClick={() => { if(id) { chatService.clearChat(id); loadMessages(); } setIsMenuOpen(false); }} style={{display: 'flex', alignItems: 'center', padding: '12px 15px', color: '#fff', background: 'none', border: 'none', fontSize: '14px', cursor: 'pointer', textAlign: 'left', width: '100%', borderBottom: '1px solid rgba(255,255,255,0.05)'}}>
                              <i className="fa-solid fa-eraser" style={{marginRight: '10px', width: '20px', textAlign: 'center'}}></i> Limpar Chat
                          </button>
                      </div>
                  )}
              </div>
          </div>
      </header>

      {/* MEDIA GALLERY MODAL */}
      {isGalleryOpen && (
          <div className="gallery-modal-overlay">
              <div className="gallery-header">
                  <span style={{fontSize: '16px', fontWeight: 700}}>Mídia do Grupo</span>
                  <button onClick={() => { setIsGalleryOpen(false); setGalleryViewerIndex(null); }} style={{background:'none', border:'none', color:'#fff', fontSize:'20px'}}>
                      <i className="fa-solid fa-xmark"></i>
                  </button>
              </div>
              <div className="gallery-tabs">
                  <div className={`gallery-tab ${galleryTab === 'all' ? 'active' : ''}`} onClick={() => setGalleryTab('all')}>
                      Todos ({allMedia.length})
                  </div>
                  <div className={`gallery-tab ${galleryTab === 'image' ? 'active' : ''}`} onClick={() => setGalleryTab('image')}>
                      Fotos ({photos.length})
                  </div>
                  <div className={`gallery-tab ${galleryTab === 'video' ? 'active' : ''}`} onClick={() => setGalleryTab('video')}>
                      Vídeos ({videos.length})
                  </div>
              </div>
              
              {/* NO SELECTION MODE HERE - PURE VIEWING */}
              <div className="gallery-grid">
                  {currentGalleryItems.map((item, index) => (
                      <div key={item.id} className="gallery-item" onClick={() => setGalleryViewerIndex(index)}>
                          {item.contentType === 'video' ? (
                              <video src={item.mediaUrl} />
                          ) : (
                              <img src={item.mediaUrl} />
                          )}
                          {item.contentType === 'video' && <div className="video-indicator"><i className="fa-solid fa-video"></i></div>}
                      </div>
                  ))}
                  {currentGalleryItems.length === 0 && (
                      <div style={{gridColumn: '1/-1', textAlign: 'center', padding: '40px', color: '#666'}}>
                          Nenhuma mídia encontrada.
                      </div>
                  )}
              </div>
          </div>
      )}

      {/* GALLERY VIEWER LIGHTBOX (VIEW & NAVIGATE ONLY) */}
      {galleryViewerIndex !== null && isGalleryOpen && currentGalleryItems[galleryViewerIndex] && (
        <div className="fixed inset-0 z-[120] bg-black flex flex-col items-center justify-center p-0" onClick={() => setGalleryViewerIndex(null)}>
            {/* Toolbar */}
            <div className="absolute top-0 left-0 w-full p-4 flex justify-between items-center bg-gradient-to-b from-black/70 to-transparent z-10" onClick={(e) => e.stopPropagation()}>
                <span className="text-white text-sm font-medium">{galleryViewerIndex + 1} / {currentGalleryItems.length}</span>
                <button 
                    className="text-white text-2xl w-10 h-10 flex items-center justify-center rounded-full bg-black/20 backdrop-blur-sm"
                    onClick={() => setGalleryViewerIndex(null)}
                >
                    &times;
                </button>
            </div>

            {/* Main Content */}
            <div className="w-full h-full flex items-center justify-center relative">
                {currentGalleryItems[galleryViewerIndex].contentType === 'video' ? (
                    <video 
                        src={currentGalleryItems[galleryViewerIndex].mediaUrl} 
                        controls 
                        autoPlay 
                        className="max-w-full max-h-full object-contain"
                        onClick={(e) => e.stopPropagation()} 
                    />
                ) : (
                    <img 
                        src={currentGalleryItems[galleryViewerIndex].mediaUrl} 
                        className="max-w-full max-h-full object-contain"
                        onClick={(e) => e.stopPropagation()} 
                    />
                )}
            </div>

            {/* Navigation Arrows */}
            {galleryViewerIndex > 0 && (
                <button 
                    className="absolute left-4 top-1/2 -translate-y-1/2 text-white text-3xl bg-black/30 p-3 rounded-full hover:bg-black/50 transition-all z-20"
                    onClick={(e) => { e.stopPropagation(); setGalleryViewerIndex(galleryViewerIndex - 1); }}
                >
                    <i className="fa-solid fa-chevron-left"></i>
                </button>
            )}
            
            {galleryViewerIndex < currentGalleryItems.length - 1 && (
                <button 
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-white text-3xl bg-black/30 p-3 rounded-full hover:bg-black/50 transition-all z-20"
                    onClick={(e) => { e.stopPropagation(); setGalleryViewerIndex(galleryViewerIndex + 1); }}
                >
                    <i className="fa-solid fa-chevron-right"></i>
                </button>
            )}
        </div>
      )}

      <main style={{flexGrow:1, width:'100%', padding: '70px 10px 80px 10px', overflowY: 'auto', display: 'flex', flexDirection: 'column'}}>
          {/* Creator Warning */}
          {isCreator && group?.isVip && group?.status === 'inactive' && (
              <div className="bg-red-500/20 text-red-200 text-xs p-2 text-center cursor-pointer mb-2 rounded border border-red-500/30" onClick={() => navigate('/financial/providers')}>
                  <i className="fa-solid fa-triangle-exclamation mr-1"></i>
                  Grupo Inativo: Conecte um provedor de pagamento para ativar vendas. Clique aqui.
              </div>
          )}

          {/* Empty State */}
          {displayMessages.length === 0 && (
              <div className="flex flex-col items-center justify-center h-full opacity-50 mt-20">
                  <i className="fa-regular fa-comments text-4xl mb-2 text-[#00c2ff]"></i>
                  <p>{searchQuery ? 'Nenhum resultado encontrado.' : 'Nenhuma mensagem ainda.'}</p>
              </div>
          )}

          {/* Messages List */}
          {displayMessages.map((msg) => {
              const isMe = msg.senderEmail ? msg.senderEmail === currentUserEmail : msg.type === 'sent';
              return (
                  <div key={msg.id} className={`message-container ${isMe ? 'sent' : 'received'}`} style={{display: 'flex', marginBottom: '8px', alignItems: 'flex-end', justifyContent: isMe ? 'flex-end' : 'flex-start'}}>
                      <div className="message-bubble" style={{
                          maxWidth: '75%', padding: '8px 12px', borderRadius: '12px',
                          fontSize: '15px', lineHeight: 1.4, position: 'relative', minWidth: '80px',
                          backgroundColor: isMe ? '#0088cc' : '#2e3646',
                          color: '#fff',
                          borderBottomRightRadius: isMe ? '2px' : '12px',
                          borderBottomLeftRadius: isMe ? '12px' : '2px',
                          border: '1px solid rgba(255,255,255,0.1)'
                      }}>
                          {!isMe && (
                              <div className="sender-name" style={{fontSize: '10px', fontWeight: 700, marginBottom: '2px', color: 'rgba(255,255,255,0.6)', display: 'flex', alignItems: 'center', gap: '5px'}}>
                                  {msg.senderAvatar && <img src={msg.senderAvatar} className="sender-avatar" style={{width: '16px', height: '16px', borderRadius: '50%', objectFit: 'cover'}} />}
                                  {msg.senderName}
                              </div>
                          )}
                          
                          {/* Audio Content */}
                          {msg.contentType === 'audio' && (
                              <div className={`audio-player ${playingAudioId === msg.id ? 'playing' : ''}`} style={{display: 'flex', alignItems: 'center', gap: '8px', width: '260px', padding: '10px 8px', background: 'rgba(0,0,0,0.2)', borderRadius: '10px'}}>
                                  <div 
                                      className={`audio-control ${playingAudioId === msg.id ? 'playing' : ''}`}
                                      onClick={() => handlePlayAudio(msg.id, msg.duration)}
                                      style={{
                                          width: '45px', height: '45px', borderRadius: '50%', background: playingAudioId === msg.id ? '#00c2ff' : 'rgba(255,255,255,0.2)', 
                                          display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', flexShrink: 0, fontSize: '18px', color: playingAudioId === msg.id ? '#000' : '#fff'
                                      }}
                                  >
                                      <i className={`fa-solid ${playingAudioId === msg.id ? 'fa-pause' : 'fa-play'}`}></i>
                                  </div>
                                  <div className="audio-info" style={{display: 'flex', flexDirection: 'column', flexGrow: 1, justifyContent: 'center'}}>
                                      <span style={{fontSize:'13px', fontWeight: 'bold'}}>Áudio ({msg.duration})</span>
                                      <div className="audio-waveform" style={{height: '6px', background: 'rgba(255,255,255,0.3)', borderRadius: '3px', width: '100%', marginTop: '6px', position: 'relative', overflow: 'hidden'}}>
                                          <div className="audio-progress" style={{height: '100%', background: '#00c2ff', borderRadius: '3px', width: playingAudioId === msg.id ? '100%' : '0%', transition: playingAudioId === msg.id ? 'width 3s linear' : 'width 0.2s linear'}}></div>
                                      </div>
                                  </div>
                              </div>
                          )}

                          {/* Image Content */}
                          {msg.contentType === 'image' && msg.mediaUrl && (
                              <div className="media-content" style={{width: '100%', maxWidth: '320px', borderRadius: '12px', marginBottom: '5px', overflow: 'hidden', background: '#000', border: '1px solid rgba(255,255,255,0.1)'}}>
                                  <img 
                                    src={msg.mediaUrl} 
                                    alt="Mídia" 
                                    style={{width: '100%', height: 'auto', display: 'block', maxHeight: '450px', objectFit: 'contain', cursor: 'pointer'}} 
                                    onClick={(e) => { e.stopPropagation(); setZoomedMedia({ url: msg.mediaUrl!, type: 'image' }); }}
                                  />
                              </div>
                          )}
                          
                          {/* Video Content */}
                          {msg.contentType === 'video' && msg.mediaUrl && (
                              <div className="media-content" style={{width: '100%', maxWidth: '320px', borderRadius: '12px', marginBottom: '5px', overflow: 'hidden', background: '#000', border: '1px solid rgba(255,255,255,0.1)', position: 'relative'}}>
                                  <video src={msg.mediaUrl} style={{width: '100%', height: 'auto', display: 'block', maxHeight: '450px', objectFit: 'contain'}} />
                                  <button 
                                      onClick={(e) => { e.stopPropagation(); setZoomedMedia({ url: msg.mediaUrl!, type: 'video' }); }}
                                      style={{
                                          position: 'absolute', top: '10px', right: '10px', 
                                          background: 'rgba(0,0,0,0.6)', border: 'none', borderRadius: '50%', 
                                          width: '30px', height: '30px', color: 'white', cursor: 'pointer',
                                          display: 'flex', alignItems: 'center', justifyContent: 'center'
                                      }}
                                  >
                                      <i className="fa-solid fa-expand"></i>
                                  </button>
                                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                                      <i className="fa-solid fa-play text-4xl text-white opacity-50"></i>
                                  </div>
                              </div>
                          )}

                          {/* File Content */}
                          {msg.contentType === 'file' && msg.mediaUrl && (
                              <a 
                                  href={msg.mediaUrl} 
                                  download={msg.fileName || 'arquivo'} 
                                  className="flex items-center gap-3 p-3 bg-black/20 rounded-lg border border-white/10 hover:bg-black/40 transition-colors cursor-pointer no-underline text-white"
                                  target="_blank"
                                  rel="noopener noreferrer"
                              >
                                  <div className="w-10 h-10 bg-[#00c2ff]/20 rounded-lg flex items-center justify-center flex-shrink-0 text-[#00c2ff]">
                                      <i className="fa-solid fa-file-lines text-xl"></i>
                                  </div>
                                  <div className="flex flex-col overflow-hidden">
                                      <span className="font-semibold text-sm truncate">{msg.fileName || 'Arquivo'}</span>
                                      <span className="text-xs text-gray-300">Clique para baixar</span>
                                  </div>
                              </a>
                          )}

                          {/* Text Content */}
                          {msg.text && (msg.contentType === 'text' || (msg.text !== 'Foto' && msg.text !== 'Vídeo' && msg.text !== 'Mensagem de Voz' && msg.text !== 'Arquivo')) && (
                              <div className={`message-text ${msg.contentType !== 'text' ? 'mt-1' : ''}`} style={{wordBreak: 'break-word', whiteSpace: 'pre-wrap', color: '#fff'}}>
                                  {msg.text}
                              </div>
                          )}
                          
                          <div className="message-meta" style={{display: 'flex', justifyContent: 'flex-end', alignItems: 'center', fontSize: '10px', marginTop: '4px', gap: '4px', opacity: 0.8}}>
                              <span>{msg.timestamp}</span>
                              {isMe && renderStatusIcon(msg.status)}
                          </div>
                      </div>
                  </div>
              );
          })}
          <div ref={messagesEndRef} />
          <div style={{ height: '20px' }}></div> 
      </main>

      {/* INPUT AREA */}
      {canPost ? (
          <div className="chat-input-area" style={{
            position: 'fixed', bottom: '0', width: '100%', background: '#0c0f14',
            padding: '8px 10px', display: 'flex', alignItems: 'center',
            borderTop: '1px solid rgba(255,255,255,0.1)', zIndex: 15, paddingBottom: '20px'
          }}>
              {cooldown > 0 ? (
                  <div className="slow-mode-container">
                      <div 
                        className="slow-mode-progress" 
                        style={{ width: `${(cooldown / maxCooldown) * 100}%` }} 
                      ></div>
                      <div className="slow-mode-content">
                          <i className="fa-solid fa-hourglass-half slow-mode-icon"></i>
                          <span>Modo Lento: aguarde {cooldown}s</span>
                      </div>
                  </div>
              ) : isRecording ? (
                  <>
                      <div className="recording-ui" style={{flexGrow: 1, display: 'flex', alignItems: 'center', padding: '0 10px', color: '#ff4d4d'}}>
                          <div className="recording-dot" style={{width: '10px', height: '10px', background: '#ff4d4d', borderRadius: '50%', marginRight: '10px'}}></div>
                          <span>Gravando {formatTime(recordingTime)}</span>
                      </div>
                      <button onClick={cancelRecording} style={{color: '#ff4d4d', fontSize: '14px', fontWeight: 'bold', background:'none', border:'none', cursor:'pointer', marginRight: '10px'}}>
                          Cancelar
                      </button>
                  </>
              ) : (
                  <>
                      <input 
                          type="text" 
                          placeholder="Mensagem..." 
                          value={inputText}
                          onChange={(e) => setInputText(e.target.value)}
                          onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                          style={{
                              flexGrow: 1, padding: '10px 15px', border: '2px solid rgba(0,194,255,0.2)', borderRadius: '25px',
                              background: 'rgba(255,255,255,0.05)', color: '#fff', fontSize: '16px', marginRight: '8px', outline: 'none'
                          }}
                      />

                      <div style={{display: 'flex', gap: '4px', alignItems: 'center'}}>
                          <button className="attachment-button" onClick={handleDocClick} style={{background:'none', border:'none', color:'#00c2ff', fontSize:'20px', cursor:'pointer', padding:'8px'}}>
                              <i className="fa-solid fa-paperclip"></i>
                          </button>
                          <button className="attachment-button" onClick={handleAttachmentClick} style={{background:'none', border:'none', color:'#00c2ff', fontSize:'20px', cursor:'pointer', padding:'8px'}}>
                              <i className="fa-solid fa-image"></i>
                          </button>
                      </div>
                      
                      <input type="file" ref={fileInputRef} accept="image/*,video/*" style={{display:'none'}} onChange={(e) => handleFileChange(e, false)} />
                      <input type="file" ref={docInputRef} accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,.zip,.rar" style={{display:'none'}} onChange={(e) => handleFileChange(e, true)} />
                  </>
              )}
              
              <button 
                id="sendButton" 
                onClick={handleAudioAction} 
                disabled={cooldown > 0}
                style={{background:'none', border:'none', color: cooldown > 0 ? '#555' : '#00c2ff', fontSize:'20px', cursor: cooldown > 0 ? 'not-allowed' : 'pointer', padding:'8px'}}
              >
                  <i className={`fa-solid ${inputText.trim() ? 'fa-paper-plane' : (isRecording ? 'fa-paper-plane' : 'fa-microphone')}`}></i>
              </button>
          </div>
      ) : (
          <div className="restricted-input-area">
              <i className="fa-solid fa-lock"></i>
              <span>Apenas administradores podem enviar mensagens.</span>
          </div>
      )}

      {/* MEDIA PREVIEW OVERLAY */}
      {mediaPreview && (
          <div className="fixed inset-0 z-[60] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
              <div className="w-full max-w-sm bg-[#1a1e26] rounded-2xl overflow-hidden shadow-2xl border border-white/10 transform transition-all scale-100 flex flex-col">
                  <div className="relative w-full bg-black flex items-center justify-center aspect-square" style={{ maxHeight: '60vh' }}>
                      {mediaPreview.type === 'video' ? (
                          <video src={mediaPreview.url} controls className="w-full h-full object-contain" />
                      ) : mediaPreview.type === 'image' ? (
                          <img src={mediaPreview.url} alt="Preview" className="w-full h-full object-contain" />
                      ) : (
                          <div className="flex flex-col items-center justify-center p-6 text-gray-300">
                              <i className="fa-solid fa-file-lines text-6xl mb-4 text-[#00c2ff]"></i>
                              <p className="text-center font-semibold break-all px-4">{mediaPreview.file.name}</p>
                              <p className="text-xs text-gray-500 mt-2">{(mediaPreview.file.size / 1024).toFixed(1)} KB</p>
                          </div>
                      )}
                      
                      <button onClick={() => setMediaPreview(null)} className="absolute top-3 right-3 w-8 h-8 rounded-full bg-black/50 text-white flex items-center justify-center hover:bg-black/70 transition-colors backdrop-blur-sm z-10">
                          <i className="fa-solid fa-xmark"></i>
                      </button>
                  </div>

                  <div className="p-3 bg-[#1a1e26] flex gap-2 items-center">
                      <input 
                          type="text" 
                          placeholder="Adicione uma legenda..." 
                          value={mediaCaption}
                          onChange={(e) => setMediaCaption(e.target.value)}
                          className="flex-1 bg-[#0c0f14] text-gray-100 text-sm px-4 py-3 rounded-xl border border-white/5 focus:border-[#00c2ff]/50 outline-none transition-all placeholder-gray-500"
                          autoFocus
                      />
                      <button onClick={handleSendMedia} className="w-12 h-12 bg-[#00c2ff] rounded-xl text-black flex items-center justify-center text-lg hover:bg-[#00aaff] transition-transform active:scale-95 shadow-lg shadow-blue-500/20">
                          <i className="fa-solid fa-paper-plane"></i>
                      </button>
                  </div>
              </div>
          </div>
      )}

      {/* LIGHTBOX OVERLAY */}
      {zoomedMedia && !mediaPreview && (
          <div className="fixed inset-0 z-[60] bg-black bg-opacity-95 flex items-center justify-center p-2" onClick={() => setZoomedMedia(null)}>
              <button className="absolute top-4 right-4 text-white text-4xl bg-black/50 rounded-full w-10 h-10 flex items-center justify-center z-50" onClick={() => setZoomedMedia(null)}>
                  &times;
              </button>
              {zoomedMedia.type === 'video' ? (
                  <video src={zoomedMedia.url} controls autoPlay className="max-w-full max-h-full object-contain shadow-2xl" onClick={(e) => e.stopPropagation()} />
              ) : (
                  <img src={zoomedMedia.url} alt="Zoom" className="max-w-full max-h-full object-contain rounded-lg shadow-2xl" onClick={(e) => e.stopPropagation()} />
              )}
          </div>
      )}
    </div>
  );
};
