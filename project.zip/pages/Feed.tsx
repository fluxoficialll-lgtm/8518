
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { authService } from '../services/authService';
import { postService } from '../services/postService';
import { notificationService } from '../services/notificationService';
import { chatService } from '../services/chatService';
import { Post } from '../types';
import { db } from '@/database';
import { ImageCarousel } from '../components/ImageCarousel';
import { GroupAttachmentCard } from '../components/GroupAttachmentCard';

// --- Helper: Format Numbers ---
const formatNumber = (num: number): string => {
    if (num >= 1000000) return (num / 1000000).toFixed(1).replace(/\.0$/, '') + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1).replace(/\.0$/, '') + 'k';
    return num.toString();
};

// Helper Component for Post Header
const PostHeader: React.FC<{ username: string, time: string, location?: string, isAdult?: boolean, isAd?: boolean, onClick: () => void }> = ({ username, time, location, isAdult, isAd, onClick }) => {
    const [displayName, setDisplayName] = useState(username);
    const [avatarUrl, setAvatarUrl] = useState<string | undefined>(undefined);

    useEffect(() => {
        const user = authService.getUserByHandle(username);
        if (user) {
            setDisplayName(user.profile?.nickname || user.profile?.name || username);
            setAvatarUrl(user.profile?.photoUrl);
        }
    }, [username]);

    return (
        <div className="flex items-center justify-between mb-2.5">
            <div className="flex items-center gap-3 cursor-pointer" onClick={onClick}>
                {avatarUrl ? (
                    <img src={avatarUrl} alt={displayName} loading="lazy" className="w-10 h-10 rounded-full border-2 border-[#00c2ff] object-cover" />
                ) : (
                    <div className="w-10 h-10 rounded-full border-2 border-[#0c0f14] bg-[#1e2531] flex items-center justify-center text-[#00c2ff]">
                        <i className="fa-solid fa-user"></i>
                    </div>
                )}
                <div className="flex flex-col">
                    <span className="font-semibold text-base hover:text-[#00c2ff] transition-colors flex items-center gap-2">
                        {displayName}
                        {isAdult && <span className="bg-[#ff4d4d] text-white text-[9px] font-bold px-1.5 rounded ml-1.5">18+</span>}
                        {isAd && <span className="bg-white/15 text-gray-300 text-[9px] font-semibold px-1.5 rounded ml-1.5 border border-white/10">Patrocinado</span>}
                    </span>
                    <div className="flex flex-col">
                        <span className="text-xs text-[#aaa]">{isAd ? 'Publicidade' : time}</span>
                        {location && (
                            <span className="text-[11px] text-[#00c2ff] flex items-center gap-1 mt-0.5">
                                <i className="fa-solid fa-location-dot text-[9px]"></i> {location}
                            </span>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export const Feed: React.FC = () => {
  const navigate = useNavigate();
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  
  const [posts, setPosts] = useState<Post[]>([]);
  const [uiVisible, setUiVisible] = useState(true);
  const [activeLocationFilter, setActiveLocationFilter] = useState<string | null>(null);
  
  const [nextCursor, setNextCursor] = useState<number | undefined>(undefined);
  const [loading, setLoading] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const PAGE_SIZE = 8; 

  const lastScrollY = useRef(0);
  
  const [unreadNotifs, setUnreadNotifs] = useState(0);
  const [unreadMsgs, setUnreadMsgs] = useState(0);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  // Zoom State
  const [zoomedImage, setZoomedImage] = useState<string | null>(null);

  const loaderRef = useRef<HTMLDivElement>(null);
  const isAdultContentAllowed = localStorage.getItem('settings_18_plus') === 'true';

  useEffect(() => {
    const userEmail = authService.getCurrentUserEmail();
    if (!userEmail) {
      navigate('/');
      return;
    }
    const filter = localStorage.getItem('feed_location_filter');
    setActiveLocationFilter(filter);
    
    loadInitialPosts();
  }, [navigate]);

  useEffect(() => {
      const updateCounts = () => {
          setUnreadNotifs(notificationService.getUnreadCount());
          setUnreadMsgs(chatService.getUnreadCount());
      };
      updateCounts();
      const unsubNotif = db.subscribe('notifications', updateCounts);
      const unsubChat = db.subscribe('chats', updateCounts);
      return () => { unsubNotif(); unsubChat(); };
  }, []);

  const loadInitialPosts = () => {
      setPosts([]);
      setNextCursor(undefined);
      setHasMore(true);
      fetchPosts(undefined, true);
  };

  const fetchPosts = useCallback(async (cursor?: number, reset = false) => {
    if (loading) return;
    setLoading(true);
    
    try {
        const locationFilter = localStorage.getItem('feed_location_filter');
        
        const response = await postService.getFeedPaginated({
            limit: PAGE_SIZE,
            cursor: cursor,
            allowedTypes: ['text', 'photo', 'poll'], // Removed 'video' to restrict feed
            locationFilter: locationFilter,
            allowAdultContent: isAdultContentAllowed 
        });
        
        let fetchedPosts = response.data;
        // Strictly filter out organic videos from Feed. Ads are allowed.
        fetchedPosts = fetchedPosts.filter(p => p.type !== 'video' || p.isAd);

        setPosts(prev => {
            if (reset) return fetchedPosts;
            const existingIds = new Set(prev.map(p => p.id));
            const uniqueNew = fetchedPosts.filter(p => !existingIds.has(p.id));
            return [...prev, ...uniqueNew];
        });

        setNextCursor(response.nextCursor);
        setHasMore(!!response.nextCursor && fetchedPosts.length > 0);

    } catch (error) {
        console.error("Feed error", error);
    } finally {
        setLoading(false);
    }
  }, [isAdultContentAllowed, loading]);

  useEffect(() => {
      const observer = new IntersectionObserver(
          (entries) => {
              const target = entries[0];
              if (target.isIntersecting && hasMore && !loading) {
                  fetchPosts(nextCursor);
              }
          },
          { 
              root: scrollContainerRef.current,
              rootMargin: '300px',
              threshold: 0.1 
          }
      );

      if (loaderRef.current) {
          observer.observe(loaderRef.current);
      }

      return () => observer.disconnect();
  }, [hasMore, loading, nextCursor, fetchPosts]);

  const handleContainerScroll = () => {
      if (!scrollContainerRef.current) return;
      const currentScroll = scrollContainerRef.current.scrollTop;
      
      if (currentScroll > lastScrollY.current && currentScroll > 100) {
          setUiVisible(false);
      } else {
          setUiVisible(true);
      }
      lastScrollY.current = currentScroll;
  };

  const handleLike = (id: string) => {
    setPosts(prev => prev.map(post => {
      if (post.id === id) {
        const newLiked = !post.liked;
        return {
          ...post,
          liked: newLiked,
          likes: post.likes + (newLiked ? 1 : -1)
        };
      }
      return post;
    }));
    postService.toggleLike(id);
  };

  const handleVote = (postId: string, optionIndex: number) => {
    setPosts(prev => prev.map(post => {
        if (post.id === postId && post.pollOptions && post.votedOptionIndex == null) {
            const newOptions = [...post.pollOptions];
            newOptions[optionIndex].votes += 1;
            return {
                ...post,
                pollOptions: newOptions,
                votedOptionIndex: optionIndex
            };
        }
        return post;
    }));
  };

  const handleUserClick = (username: string) => {
    const cleanName = username.startsWith('@') ? username.substring(1) : username;
    navigate(`/user/${cleanName}`);
  };

  const handleCtaClick = (link?: string) => {
      if (!link) return;
      if (link.startsWith('http')) {
          window.open(link, '_blank');
      } else {
          navigate(link);
      }
  };

  const handleShare = async (post: Post) => {
      const url = `${window.location.origin}/#/post/${post.id}`;
      if (navigator.share) {
          try {
              await navigator.share({
                  title: `Post de ${post.username}`,
                  text: post.text.substring(0, 100),
                  url: url
              });
          } catch (err) {
              console.error('Share failed:', err);
          }
      } else {
          navigator.clipboard.writeText(url);
          alert('Link copiado para a área de transferência!');
      }
  };

  const getPercentage = (votes: number, total: number) => {
    if (total === 0) return 0;
    return Math.round((votes / total) * 100);
  };

  const handleOptionSelect = (destination: 'feed' | 'reels' | 'marketplace') => {
      setIsMenuOpen(false);
      if (destination === 'feed') navigate('/create-post');
      else if (destination === 'reels') navigate('/create-reel');
      else navigate('/create-marketplace-item', { state: { type: 'organic' } });
  };

  return (
    <div className="h-screen bg-[radial-gradient(circle_at_top_left,_#0c0f14,_#0a0c10)] text-white font-['Inter'] flex flex-col overflow-hidden relative">
      
      {/* HEADER FIXED */}
      <header className="flex items-center justify-between p-[16px_32px] bg-[#0c0f14] w-full z-30 border-b border-white/10 h-[80px] shrink-0 relative">
        <button onClick={() => navigate('/location-filter')} className="bg-none border-none text-[#00c2ff] text-lg cursor-pointer hover:text-white z-30">
            <i className={`fa-solid ${activeLocationFilter ? 'fa-location-dot' : 'fa-globe'}`}></i>
        </button>
        
        {/* LOGO CENTRALIZADA */}
        <div className="absolute left-1/2 -translate-x-1/2 w-[60px] h-[60px] bg-white/5 rounded-2xl flex justify-center items-center z-20 cursor-pointer shadow-[0_0_20px_rgba(0,194,255,0.3),inset_0_0_20px_rgba(0,194,255,0.08)]" onClick={() => scrollContainerRef.current?.scrollTo({top: 0, behavior: 'smooth'})}>
             <div className="absolute w-[40px] h-[22px] rounded-[50%] border-[3px] border-[#00c2ff] rotate-[25deg]"></div>
             <div className="absolute w-[40px] h-[22px] rounded-[50%] border-[3px] border-[#00c2ff] -rotate-[25deg]"></div>
        </div>

        {/* CART ICON (Right) */}
        <button onClick={() => navigate('/marketplace')} className="bg-none border-none text-[#00c2ff] text-lg cursor-pointer hover:text-white z-30">
            <i className="fa-solid fa-cart-shopping"></i>
        </button>
      </header>

      {/* FLOATING TOGGLE BUTTONS */}
      <div className="fixed top-[90px] left-1/2 -translate-x-1/2 flex gap-5 z-20 bg-black/20 p-2 px-4 rounded-xl backdrop-blur-md">
          <button className="bg-white/20 text-[#00c2ff] px-4 py-1.5 rounded-lg text-base cursor-pointer" onClick={() => { /* Already on Feed */ }}>Feed</button>
          <button className="bg-transparent border border-white/40 text-white px-4 py-1.5 rounded-lg text-base cursor-pointer" onClick={() => navigate('/reels')}>Reels</button>
      </div>

      {/* SCROLLABLE CONTAINER */}
      <main 
        ref={scrollContainerRef}
        onScroll={handleContainerScroll}
        className="flex-grow w-full overflow-y-auto overflow-x-hidden relative pt-[140px]" 
        style={{ WebkitOverflowScrolling: 'touch' }}
      >
        {activeLocationFilter && (
            <div className="w-full bg-[#00c2ff1a] text-[#00c2ff] text-center p-2 text-sm font-semibold border-b border-[#00c2ff33] sticky top-0 z-[9] backdrop-blur-sm">
                <i className="fa-solid fa-location-dot mr-1"></i> {activeLocationFilter}
            </div>
        )}

        <div className="w-full max-w-[500px] mx-auto pb-[100px]">
            
            <div className="px-4 pt-2">
                {posts.map((post) => (
                    <div key={post.id} className="relative bg-white/5 backdrop-blur-md rounded-2xl pt-4 pb-2 mb-5 shadow-lg border border-white/5 overflow-hidden">
                        <div className="px-4">
                            <PostHeader 
                                username={post.username} 
                                time={post.time} 
                                location={activeLocationFilter ? post.location : undefined}
                                isAdult={post.isAdultContent}
                                isAd={post.isAd}
                                onClick={() => handleUserClick(post.username)}
                            />

                            <p className="mb-3 text-[15px] leading-[1.5] whitespace-pre-wrap break-words text-gray-100">
                                {post.text}
                            </p>
                        </div>

                        {/* CONTENT RENDERER */}
                        {post.type === 'photo' && (
                            <div className="w-full overflow-hidden bg-black mb-0">
                                {post.images && post.images.length > 1 ? (
                                    <ImageCarousel images={post.images} onImageClick={(url) => setZoomedImage(url)} />
                                ) : (
                                    post.image && (
                                        <img 
                                            src={post.image} 
                                            loading="lazy"
                                            alt="Post content" 
                                            className="w-full h-auto max-h-[600px] object-contain cursor-pointer" 
                                            onClick={() => setZoomedImage(post.image!)}
                                        />
                                    )
                                )}
                            </div>
                        )}

                        {post.type === 'video' && post.video && (
                            <div className="w-full overflow-hidden bg-black mb-0">
                                <video 
                                    src={post.video} 
                                    controls 
                                    className="w-full h-auto max-h-[600px] object-contain" 
                                />
                            </div>
                        )}

                        {/* CTA Banner for Ads */}
                        {post.isAd && post.ctaLink && (
                            <div className="bg-[#1a1e26] p-2.5 px-4 flex justify-between items-center mb-2.5 border-y border-white/5">
                                <span className="text-xs text-[#aaa] font-medium">{post.ctaLink.includes('http') ? 'Acesse o site oficial' : 'Veja mais detalhes'}</span>
                                <button className="bg-[#00c2ff] text-black border-none px-3.5 py-1.5 rounded-md text-xs font-bold flex items-center gap-1.5" onClick={() => handleCtaClick(post.ctaLink)}>
                                    {post.ctaText || 'Saiba Mais'} <i className="fa-solid fa-chevron-right text-[10px]"></i>
                                </button>
                            </div>
                        )}

                        {/* Group Attachment */}
                        {post.relatedGroupId && (
                            <GroupAttachmentCard groupId={post.relatedGroupId} />
                        )}

                        {post.type === 'poll' && post.pollOptions && (
                            <div className="mx-4 mt-2.5 mb-2.5 p-2.5 bg-[#00c2ff0d] rounded-lg">
                                {(() => {
                                    const totalVotes = post.pollOptions!.reduce((acc, curr) => acc + curr.votes, 0);
                                    return post.pollOptions!.map((option, idx) => {
                                        const pct = getPercentage(option.votes, totalVotes);
                                        const isVoted = post.votedOptionIndex === idx;
                                        return (
                                            <div 
                                                key={idx}
                                                onClick={() => handleVote(post.id, idx)}
                                                className={`relative mb-2 p-3 rounded-lg cursor-pointer overflow-hidden font-medium transition-colors ${isVoted ? 'bg-[#00c2ff] text-black font-bold' : 'bg-[#1e2531] hover:bg-[#28303f]'}`}
                                            >
                                                <div 
                                                    className="absolute top-0 left-0 h-full bg-[#00c2ff] opacity-30 z-0 transition-all duration-500" 
                                                    style={{ width: `${pct}%` }}
                                                ></div>
                                                <div className="relative z-10 flex justify-between items-center text-sm">
                                                    <span>{option.text}</span>
                                                    <span>{pct}%</span>
                                                </div>
                                            </div>
                                        );
                                    });
                                })()}
                            </div>
                        )}

                        {/* Updated Footer Layout - 4 Columns Equal Sized */}
                        <div className="grid grid-cols-4 px-2 py-3 mt-2 border-t border-white/5 gap-1">
                            <button 
                                onClick={() => handleLike(post.id)}
                                className={`flex items-center justify-center gap-1.5 transition-all ${post.liked ? 'text-red-500' : 'text-gray-400 hover:text-[#00c2ff]'}`}
                            >
                                <i className={`${post.liked ? 'fa-solid' : 'fa-regular'} fa-heart text-lg`}></i>
                                <span className="text-xs font-semibold">{formatNumber(post.likes)}</span>
                            </button>
                            
                            <button 
                                onClick={() => navigate(`/post/${post.id}`)}
                                className="flex items-center justify-center gap-1.5 text-gray-400 hover:text-[#00c2ff] transition-all"
                            >
                                <i className="fa-regular fa-comment text-lg"></i>
                                <span className="text-xs font-semibold">{formatNumber(post.comments)}</span>
                            </button>

                            <button 
                                onClick={() => handleShare(post)}
                                className="flex items-center justify-center text-gray-400 hover:text-[#00c2ff] transition-all"
                            >
                                <i className="fa-regular fa-paper-plane text-lg"></i>
                            </button>

                            <div className="flex items-center justify-center gap-1.5 text-gray-400 transition-all cursor-default">
                                <i className="fa-solid fa-eye text-lg"></i>
                                <span className="text-xs font-semibold">{formatNumber(post.views)}</span>
                            </div>
                        </div>
                    </div>
                ))}
            </div>

            {/* Loader Sentinel */}
            <div ref={loaderRef} className="w-full h-24 flex items-center justify-center py-6">
                {loading ? (
                    <div className="flex justify-center p-5 text-[#00c2ff] text-2xl">
                        <i className="fa-solid fa-circle-notch fa-spin"></i>
                    </div>
                ) : !hasMore && posts.length > 0 ? (
                    <div className="text-gray-500 text-sm font-medium opacity-60">
                        • Fim do Feed •
                    </div>
                ) : null}
                
                {!loading && posts.length === 0 && (
                    <div className="text-center text-gray-500 mt-10 flex flex-col items-center gap-3">
                        <i className="fa-solid fa-ghost text-4xl opacity-30"></i>
                        <p>Nenhum post encontrado.</p>
                    </div>
                )}
            </div>
        </div>
      </main>

      {/* FAB & Menus */}
      {isMenuOpen && <div className="fixed inset-0 bg-black/60 z-20 backdrop-blur-sm" onClick={() => setIsMenuOpen(false)}></div>}
      {isMenuOpen && (
          <div className="fixed bottom-36 right-5 flex flex-col gap-2.5 z-50 items-end">
              <button className="bg-[#1a1e26] border border-white/10 p-3 px-5 rounded-xl text-white flex items-center gap-3 shadow-lg cursor-pointer transition-all hover:-translate-x-1 hover:bg-[#252a33] hover:border-[#00c2ff] animate-slide-up" style={{animationDelay: '0.05s'}} onClick={() => handleOptionSelect('feed')}>
                  <span className="font-semibold text-sm">Feed</span>
                  <i className="fa-solid fa-pen text-[#00c2ff]"></i>
              </button>
              <button className="bg-[#1a1e26] border border-white/10 p-3 px-5 rounded-xl text-white flex items-center gap-3 shadow-lg cursor-pointer transition-all hover:-translate-x-1 hover:bg-[#252a33] hover:border-[#00c2ff] animate-slide-up" onClick={() => handleOptionSelect('reels')}>
                  <span className="font-semibold text-sm">Reels</span>
                  <i className="fa-solid fa-video text-yellow-400"></i>
              </button>
          </div>
      )}

      <button 
        onClick={() => setIsMenuOpen(!isMenuOpen)}
        className={`fixed bottom-20 right-5 w-[60px] h-[60px] bg-[#00c2ff] border-none rounded-full text-white text-2xl cursor-pointer shadow-[0_4px_15px_rgba(0,194,255,0.4)] z-30 flex items-center justify-center hover:bg-[#007bff] transition-all duration-300 ${uiVisible ? 'scale-100' : 'scale-0'} ${isMenuOpen ? 'rotate-45 bg-[#ff4d4d]' : ''}`}
      >
        <i className="fa-solid fa-plus"></i>
      </button>

      {/* FOOTER */}
      <footer className={`fixed bottom-0 left-0 w-full bg-[#0c0f14] flex justify-around py-3.5 rounded-t-2xl z-30 shadow-[0_-5px_15px_rgba(0,0,0,0.5)] transition-transform duration-300 ${uiVisible ? 'translate-y-0' : 'translate-y-full'}`}>
        <button onClick={() => scrollContainerRef.current?.scrollTo({top: 0, behavior: 'smooth'})} className="text-white text-[22px] p-2">
            <i className="fa-solid fa-newspaper"></i>
        </button>
        <button onClick={() => navigate('/messages')} className="text-[#00c2ff] text-[22px] p-2 relative">
            <i className="fa-solid fa-comments"></i>
            {unreadMsgs > 0 && <div className="absolute top-2 right-2 w-2.5 h-2.5 bg-[#ff4d4d] rounded-full border border-[#0c0f14]"></div>}
        </button>
        <button onClick={() => navigate('/notifications')} className="text-[#00c2ff] text-[22px] p-2 relative">
            <i className="fa-solid fa-bell"></i>
            {unreadNotifs > 0 && <div className="absolute top-2 right-2 w-2.5 h-2.5 bg-[#ff4d4d] rounded-full border border-[#0c0f14]"></div>}
        </button>
        <button onClick={() => navigate('/profile')} className="text-[#00c2ff] text-[22px] p-2">
            <i className="fa-solid fa-user"></i>
        </button>
      </footer>

      {/* LIGHTBOX OVERLAY */}
      {zoomedImage && (
          <div 
            className="fixed inset-0 z-[60] bg-black bg-opacity-95 flex items-center justify-center p-2"
            onClick={() => setZoomedImage(null)}
          >
              <button 
                className="absolute top-4 right-4 text-white text-4xl bg-black/50 rounded-full w-10 h-10 flex items-center justify-center"
                onClick={() => setZoomedImage(null)}
              >
                  &times;
              </button>
              <img 
                src={zoomedImage} 
                alt="Zoom" 
                className="max-w-full max-h-full object-contain rounded-lg shadow-2xl"
                onClick={(e) => e.stopPropagation()} 
              />
          </div>
      )}

    </div>
  );
};
