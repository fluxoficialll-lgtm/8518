


import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { groupService } from '../services/groupService';
import { authService } from '../services/authService';
import { Group, VipMediaItem } from '../types';

export const CreateVipGroup: React.FC = () => {
  const navigate = useNavigate();
  
  // Form States
  const [groupName, setGroupName] = useState('');
  const [description, setDescription] = useState('');
  const [coverImage, setCoverImage] = useState<string | undefined>(undefined);
  
  // VIP Door States
  const [vipMediaItems, setVipMediaItems] = useState<VipMediaItem[]>([]);
  const [vipDoorText, setVipDoorText] = useState('');

  // Price & Access States
  const [price, setPrice] = useState('');
  const [currency, setCurrency] = useState<'BRL' | 'USD' | 'EUR' | 'BTC'>('BRL');
  const [accessType, setAccessType] = useState<'lifetime' | 'temporary'>('lifetime');
  const [expirationDate, setExpirationDate] = useState('');
  
  // Modal States
  const [isDateModalOpen, setIsDateModalOpen] = useState(false);
  const [isCreating, setIsCreating] = useState(false);
  
  // Provider Check
  const [hasProvider, setHasProvider] = useState(false);

  useEffect(() => {
      // Check if user has payment provider connected
      const user = authService.getCurrentUser();
      const connected = !!user?.paymentConfig?.isConnected;
      setHasProvider(connected);
  }, []);

  const handleCoverChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (ev) => setCoverImage(ev.target?.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleVipMediaChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    // Correctly cast FileList to Array
    const fileArray = Array.from(files) as File[];
    
    // Limit total items (e.g. 10)
    if (vipMediaItems.length + fileArray.length > 10) {
        alert("Máximo de 10 itens na galeria.");
        return;
    }

    const promises = fileArray.map(file => {
        return new Promise<VipMediaItem>((resolve) => {
            const reader = new FileReader();
            reader.onload = (ev) => {
                resolve({
                    url: ev.target?.result as string,
                    type: file.type.startsWith('video/') ? 'video' : 'image'
                });
            };
            reader.readAsDataURL(file);
        });
    });

    Promise.all(promises).then(newItems => {
        setVipMediaItems(prev => [...prev, ...newItems]);
    });
  };

  const removeMediaItem = (index: number) => {
      setVipMediaItems(prev => prev.filter((_, i) => i !== index));
  };

  const handleAccessTypeChange = (type: 'lifetime' | 'temporary') => {
    setAccessType(type);
    if (type === 'temporary') {
      setIsDateModalOpen(true);
    } else {
      setExpirationDate('');
    }
  };

  const saveExpirationDate = () => {
    const dateInput = document.getElementById('expirationDate') as HTMLInputElement;
    if (dateInput && dateInput.value) {
      setExpirationDate(dateInput.value);
      setIsDateModalOpen(false);
      setAccessType('temporary');
    } else {
      alert('Por favor, selecione uma data.');
    }
  };

  // Currency Mask Handler
  const handlePriceChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      let value = e.target.value;
      
      // Remove everything that is not a digit
      value = value.replace(/\D/g, "");
      
      if (value === "") {
          setPrice("");
          return;
      }

      // Convert to float (divide by 100)
      const numericValue = parseFloat(value) / 100;
      
      // Format back to string localized (BRL style by default or simple comma)
      // Using standard BRL formatting: 1.000,00
      const formatted = numericValue.toLocaleString('pt-BR', { minimumFractionDigits: 2 });
      
      setPrice(formatted);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isCreating) return;

    // Parse the display price (e.g. "1.200,50" -> 1200.50)
    // Remove dots, replace comma with dot
    const rawPrice = price.replace(/\./g, '').replace(',', '.');
    const numericPrice = parseFloat(rawPrice);

    if (isNaN(numericPrice) || numericPrice < 6.00) {
        alert("⚠️ O preço mínimo para criar um grupo VIP é R$ 6,00 (Taxa da plataforma: R$ 3,00).");
        return;
    }

    if (accessType === 'temporary' && !expirationDate) {
        alert("🚨 Por favor, defina a data de expiração para o acesso temporário.");
        setIsDateModalOpen(true);
        return;
    }

    setIsCreating(true);
    const currentUserEmail = authService.getCurrentUserEmail();

    const newGroup: Group = {
      id: Date.now().toString(),
      name: groupName,
      description: description,
      coverImage: coverImage,
      isVip: true,
      price: numericPrice.toString(), // Store as standard float string "123.45"
      currency: currency,
      accessType: accessType,
      expirationDate: expirationDate,
      vipDoor: {
        mediaItems: vipMediaItems,
        text: vipDoorText || "Bem-vindo ao VIP!"
      },
      lastMessage: hasProvider ? "Grupo criado. Configure os conteúdos." : "Grupo INATIVO. Conecte um provedor.",
      time: "Agora",
      creatorEmail: currentUserEmail || undefined,
      members: currentUserEmail ? [currentUserEmail] : [],
      admins: currentUserEmail ? [currentUserEmail] : [],
      status: hasProvider ? 'active' : 'inactive' // Set status based on provider
    };

    try {
        await groupService.createGroup(newGroup);
        navigate('/groups');
    } catch (e) {
        alert("Erro ao criar grupo VIP.");
    } finally {
        setIsCreating(false);
    }
  };

  const getCurrencySymbol = () => {
    switch (currency) {
      case 'USD': return '$';
      case 'EUR': return '€';
      case 'BTC': return '₿';
      default: return 'R$';
    }
  };

  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top_left,_#0c0f14,_#0a0c10)] text-white font-['Inter'] flex flex-col overflow-x-hidden">
      <style>{`
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Inter',sans-serif; }
        
        header {
            display:flex; align-items:center; justify-content:space-between; padding:16px 32px;
            background: #0c0f14; position:fixed; width:100%; z-index:10; border-bottom:1px solid rgba(255,255,255,0.1);
            top: 0; height: 80px;
        }
        header button {
            background:none; border:none; color:#00c2ff; font-size:18px; cursor:pointer; transition:0.3s;
        }
        header button:hover { color:#fff; }

        main { flex-grow:1; display:flex; flex-direction:column; align-items:center; justify-content:flex-start; width:100%; padding-top: 100px; padding-bottom: 100px; }

        #groupCreationForm {
            width:100%; max-width:500px; padding:0 20px;
            display: flex; flex-direction: column; gap: 20px;
        }

        h1 {
            font-size: 24px; text-align: center; margin-bottom: 20px; 
            background: -webkit-linear-gradient(145deg, #FFD700, #B8860B); -webkit-background-clip: text; -webkit-text-fill-color: transparent;
            font-weight: 700;
        }

        /* COVER UPLOAD - ROUNDED */
        .cover-upload-container {
            display: flex; flex-direction: column; align-items: center; margin-bottom: 10px;
        }
        .cover-preview {
            width: 120px; height: 120px; border-radius: 50%;
            border: 3px solid #FFD700; background: rgba(255,255,255,0.05);
            display: flex; align-items: center; justify-content: center;
            overflow: hidden; position: relative; cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 0 20px rgba(255, 215, 0, 0.2);
        }
        .cover-preview:hover {
            border-color: #fff; box-shadow: 0 0 25px rgba(255, 215, 0, 0.4);
        }
        .cover-preview img {
            width: 100%; height: 100%; object-fit: cover;
        }
        .cover-icon {
            font-size: 40px; color: rgba(255,255,255,0.3);
        }
        .cover-label {
            margin-top: 10px; font-size: 14px; color: #FFD700; cursor: pointer; font-weight: 600;
        }

        .form-group { display: flex; flex-direction: column; }
        .form-group label { font-size: 14px; color: #FFD700; margin-bottom: 8px; font-weight: 600; }
        .form-group input, .form-group textarea {
            background: #1e2531; border: 1px solid rgba(255, 215, 0, 0.3); border-radius: 8px;
            color: #fff; padding: 12px; font-size: 16px; transition: border-color 0.3s;
        }
        .form-group input:focus, .form-group textarea:focus {
            border-color: #FFD700; outline: none; box-shadow: 0 0 5px rgba(255, 215, 0, 0.5);
        }
        .form-group textarea { resize: vertical; min-height: 100px; }

        /* VIP DOOR STYLES */
        .vip-door-section {
            border-top: 1px solid rgba(255,255,255,0.1);
            padding-top: 20px;
            margin-top: 10px;
        }
        .section-title {
            font-size: 16px; color: #FFD700; font-weight: 700; margin-bottom: 15px; display: flex; align-items: center; gap: 8px;
        }
        
        /* Media Gallery Upload */
        .media-upload-area {
            display: flex; gap: 10px; overflow-x: auto; padding-bottom: 10px;
        }
        .media-preview-item {
            width: 80px; height: 100px; flex-shrink: 0; border-radius: 8px;
            overflow: hidden; position: relative; border: 1px solid rgba(255, 215, 0, 0.3);
            background: #000;
        }
        .media-preview-item img, .media-preview-item video {
            width: 100%; height: 100%; object-fit: cover;
        }
        .remove-media-btn {
            position: absolute; top: 2px; right: 2px; background: rgba(0,0,0,0.7);
            color: #ff4d4d; border: none; width: 20px; height: 20px;
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            cursor: pointer; font-size: 12px;
        }
        .add-media-btn {
            width: 80px; height: 100px; flex-shrink: 0; border-radius: 8px;
            border: 1px dashed #FFD700; background: rgba(255, 215, 0, 0.05);
            display: flex; flex-direction: column; align-items: center; justify-content: center;
            color: #FFD700; cursor: pointer; gap: 5px;
        }
        .add-media-btn:hover { background: rgba(255, 215, 0, 0.1); }
        .add-media-btn span { font-size: 10px; font-weight: 600; text-align: center; }

        /* BUTTONS */
        .common-button {
            background: #FFD700; border: none; border-radius: 8px; color: #000;
            padding: 16px 20px; font-size: 18px; font-weight: 700; cursor: pointer;
            transition: background 0.3s, transform 0.1s; display: flex; align-items: center;
            justify-content: center; gap: 8px; box-shadow: 0 4px 8px rgba(255, 215, 0, 0.3);
            margin-top: 20px;
        }
        .common-button:hover { background: #e6c200; }
        .common-button:active { transform: scale(0.99); }
        .common-button:disabled { opacity: 0.6; cursor: not-allowed; transform: none; }

        /* PRICE & ACCESS */
        .price-group {
            display: flex; flex-direction: column; gap: 10px; padding-top: 20px;
            border-top: 1px solid rgba(255,255,255,0.1);
        }
        .price-group label { font-size: 14px; color: #FFD700; font-weight: 600; }
        .price-input-container {
            display: flex; align-items: center; background: #1e2531;
            border: 1px solid rgba(255, 215, 0, 0.3); border-radius: 8px; overflow: hidden; margin-bottom: 5px; 
        }
        .price-input-container span {
            padding: 12px; background: #28303f; color: #aaa; font-size: 16px; font-weight: 700;
            min-width: 50px; text-align: center;
        }
        .price-input-container input {
            flex-grow: 1; border: none; background: none; padding: 12px; text-align: right;
            color: #fff; font-weight: 700; 
        }
        .fee-info { font-size: 11px; color: #aaa; margin-bottom: 15px; text-align: right; }

        .radio-group-container { display: flex; gap: 10px; margin-bottom: 15px; }
        .custom-radio {
            flex: 1; display: flex; align-items: center; justify-content: center;
            padding: 10px 15px; background: #1e2531; border: 1px solid rgba(255, 215, 0, 0.3);
            border-radius: 8px; color: #fff; cursor: pointer; transition: background 0.3s;
            font-size: 14px; font-weight: 600;
        }
        .custom-radio.selected { background: #FFD700; color: #000; }
        .custom-radio i { margin-right: 8px; }

        /* CURRENCY SELECTOR */
        .currency-selector {
            display: flex; gap: 8px; margin-bottom: 15px;
        }
        .currency-option {
            flex: 1;
            padding: 10px 5px;
            background: #1e2531;
            border: 1px solid rgba(255, 215, 0, 0.3);
            border-radius: 8px;
            color: #fff;
            cursor: pointer;
            text-align: center;
            font-size: 14px;
            font-weight: 600;
            transition: all 0.3s;
            display: flex;
            align-items: center; justify-content: center;
        }
        .currency-option.selected {
            background: #FFD700; color: #000; border-color: #FFD700;
        }

        /* Modal */
        .modal-overlay {
            position: fixed; top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(0, 0, 0, 0.8); display: flex; align-items: center; justify-content: center;
            z-index: 100;
        }
        .modal-content {
            background: #0c0f14; padding: 20px; border-radius: 16px; width: 90%; max-width: 350px;
            border: 1px solid #FFD700;
        }
        .date-modal input[type="date"] {
            background: #1e2531; border: 1px solid #FFD700;
            border-radius: 8px; color: #fff; padding: 12px; font-size: 16px; width: 100%;
        }
      `}</style>

      <header>
        <button onClick={() => navigate('/create-group')}><i className="fa-solid fa-xmark"></i></button>
        
        {/* Standardized Logo */}
        <div 
            className="absolute left-1/2 -translate-x-1/2 w-[60px] h-[60px] bg-white/5 rounded-2xl flex justify-center items-center z-20 cursor-pointer shadow-[0_0_20px_rgba(0,194,255,0.3),inset_0_0_20px_rgba(0,194,255,0.08)]"
            onClick={() => navigate('/feed')}
        >
             <div className="absolute w-[40px] h-[22px] rounded-[50%] border-[3px] border-[#00c2ff] rotate-[25deg]"></div>
             <div className="absolute w-[40px] h-[22px] rounded-[50%] border-[3px] border-[#00c2ff] -rotate-[25deg]"></div>
        </div>
      </header>

      <main>
        <form id="groupCreationForm" onSubmit={handleSubmit}>
            <h1>Novo Grupo VIP</h1>
            
            {/* 0. WARNING IF NO PROVIDER */}
            {!hasProvider && (
                <div style={{
                    background: 'rgba(234, 179, 8, 0.1)', 
                    border: '1px solid #eab308', 
                    borderRadius: '8px', 
                    padding: '12px', 
                    marginBottom: '20px', 
                    fontSize: '13px', 
                    color: '#fef08a'
                }}>
                    <i className="fa-solid fa-triangle-exclamation" style={{marginRight:'8px'}}></i>
                    Atenção: Você não tem um provedor de pagamento conectado. O grupo será criado como <strong>Inativo</strong> e não poderá receber pagamentos até que você conecte uma conta em Financeiro.
                </div>
            )}

            {/* 1. CAPA */}
            <div className="cover-upload-container">
                <label htmlFor="coverImageInput" className="cover-preview">
                    {coverImage ? (
                        <img src={coverImage} alt="Cover" />
                    ) : (
                        <i className="fa-solid fa-crown cover-icon"></i>
                    )}
                </label>
                <label htmlFor="coverImageInput" className="cover-label">Definir Capa (Principal)</label>
                <input type="file" id="coverImageInput" accept="image/*" style={{display: 'none'}} onChange={handleCoverChange} />
            </div>

            {/* 2. NOME */}
            <div className="form-group">
                <label htmlFor="groupName">Nome do Grupo</label>
                <input 
                    type="text" 
                    id="groupName" 
                    value={groupName} 
                    onChange={(e) => setGroupName(e.target.value)} 
                    placeholder="Ex: Comunidade Flux Pro" 
                    required 
                />
            </div>
            
            {/* 3. DESCRIÇÃO */}
            <div className="form-group">
                <label htmlFor="groupDescription">Descrição</label>
                <textarea 
                    id="groupDescription" 
                    value={description} 
                    onChange={(e) => setDescription(e.target.value)} 
                    placeholder="Breve descrição do que os membros encontrarão."
                ></textarea>
            </div>

            {/* 4. VIP DOOR (CAROUSEL CONTENT) */}
            <div className="vip-door-section">
                <div className="section-title"><i className="fa-solid fa-door-open"></i> Conteúdo da Porta (Carrossel)</div>
                <p style={{fontSize: '12px', color: '#aaa', marginBottom: '10px'}}>Adicione fotos e vídeos para convencer os membros (aparece após a capa).</p>
                
                <div className="media-upload-area">
                    {vipMediaItems.map((item, idx) => (
                        <div key={idx} className="media-preview-item">
                            {item.type === 'video' ? (
                                <video src={item.url} />
                            ) : (
                                <img src={item.url} alt={`Preview ${idx}`} />
                            )}
                            <button type="button" className="remove-media-btn" onClick={() => removeMediaItem(idx)}>
                                <i className="fa-solid fa-xmark"></i>
                            </button>
                        </div>
                    ))}
                    
                    <label htmlFor="vipMediaInput" className="add-media-btn">
                        <i className="fa-solid fa-plus"></i>
                        <span>Adicionar<br/>Mídia</span>
                    </label>
                    <input type="file" id="vipMediaInput" accept="image/*,video/*" multiple style={{display:'none'}} onChange={handleVipMediaChange} />
                </div>

                <div className="form-group">
                    <label htmlFor="vipCopyright">Texto de Venda (Copyright)</label>
                    <textarea 
                        id="vipCopyright" 
                        value={vipDoorText} 
                        onChange={(e) => setVipDoorText(e.target.value)} 
                        placeholder="Escreva um texto persuasivo para vender o acesso ao grupo..."
                        style={{minHeight: '120px'}}
                    ></textarea>
                </div>
            </div>
            
            {/* 5. CONFIGURAÇÃO DE VENDA */}
            <div className="price-group">
                <label>Configuração de Venda (SyncPay)</label>
                
                <div className="radio-group-container">
                    <div className={`custom-radio ${accessType === 'lifetime' ? 'selected' : ''}`} onClick={() => handleAccessTypeChange('lifetime')}>
                        Vitalício
                    </div>
                    <div className={`custom-radio ${accessType === 'temporary' ? 'selected' : ''}`} onClick={() => handleAccessTypeChange('temporary')}>
                        Temporário
                    </div>
                </div>

                <div className="currency-selector">
                    <div className={`currency-option ${currency === 'BRL' ? 'selected' : ''}`} onClick={() => setCurrency('BRL')}>R$</div>
                </div>

                <div className="price-input-container">
                    <span>{getCurrencySymbol()}</span>
                    <input 
                        type="text" 
                        value={price} 
                        onChange={handlePriceChange} 
                        placeholder="0,00" 
                        required 
                    />
                </div>
                <div className="fee-info">
                    Taxa da plataforma: R$ 3,00 por venda. Mínimo: R$ 6,00.
                </div>
            </div>

            {/* 6. SALVAR */}
            <button type="submit" className="common-button" disabled={isCreating}>
                {isCreating ? <i className="fa-solid fa-circle-notch fa-spin"></i> : <><i className="fa-solid fa-check"></i> Criar e Integrar</>}
            </button>
        </form>
      </main>

      {/* EXPIRATION DATE MODAL */}
      {isDateModalOpen && (
          <div className="modal-overlay" onClick={() => setIsDateModalOpen(false)}>
            <div className="modal-content date-modal" onClick={(e) => e.stopPropagation()}>
                <h3 style={{color:'#FFD700', marginBottom:'15px', textAlign:'center'}}>Data de Expiração</h3>
                <input type="date" id="expirationDate" required />
                <button className="common-button" onClick={saveExpirationDate} style={{width:'100%', fontSize:'16px', padding:'10px'}}>
                    Confirmar
                </button>
            </div>
          </div>
      )}

    </div>
  );
};