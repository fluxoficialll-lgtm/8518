
import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { groupService } from '../services/groupService';
import { authService } from '../services/authService';
import { Group } from '../types';

type TabType = 'info' | 'membros' | 'ajustes' | 'opcoes';

export const GroupSettings: React.FC = () => {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const [group, setGroup] = useState<Group | undefined>(undefined);
  const [activeTab, setActiveTab] = useState<TabType>('info');
  const [isOwner, setIsOwner] = useState(false); // Changed variable name to isOwner for clarity
  
  // Form States (Geral)
  const [editName, setEditName] = useState('');
  const [editDesc, setEditDesc] = useState('');
  const [coverPreview, setCoverPreview] = useState<string | undefined>(undefined);

  // Members State
  const [members, setMembers] = useState<{ id: string, name: string, role: string, isMe: boolean, avatar?: string }[]>([]);
  const [memberSearch, setMemberSearch] = useState('');

  // Permissions State (Regras)
  const [settings, setSettings] = useState({
      onlyAdminsPost: false,
      approveMembers: false,
      notifications: true
  });

  useEffect(() => {
      if (id) {
          const foundGroup = groupService.getGroupById(id);
          if (foundGroup) {
              setGroup(foundGroup);
              setEditName(foundGroup.name);
              setEditDesc(foundGroup.description);
              setCoverPreview(foundGroup.coverImage);
              
              const email = authService.getCurrentUserEmail();
              setIsOwner(foundGroup.creatorEmail === email);
              
              // Load Settings
              setSettings({
                  onlyAdminsPost: foundGroup.settings?.onlyAdminsPost || false,
                  approveMembers: foundGroup.settings?.approveMembers || false,
                  notifications: true // Local state mostly
              });

              // Load members
              const rawMembers = groupService.getGroupMembers(id);
              const mappedMembers = rawMembers.map(u => ({
                  id: u.email,
                  name: u.profile?.nickname || u.profile?.name || 'Membro',
                  role: u.email === foundGroup.creatorEmail ? 'Dono' : (foundGroup.admins?.includes(u.email) ? 'Admin' : 'Membro'),
                  isMe: u.email === email,
                  avatar: u.profile?.photoUrl
              }));
              setMembers(mappedMembers);
          } else {
              navigate('/groups');
          }
      }
  }, [id, navigate]);

  const handleBack = () => {
      // Fix: Explicitly navigate to the chat instead of using history back (-1)
      if (id) {
          navigate(`/group-chat/${id}`);
      } else {
          navigate('/groups');
      }
  };

  const handleCoverChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (ev) => setCoverPreview(ev.target?.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleSaveGeneral = () => {
      if (!group) return;
      const updatedGroup = { ...group, name: editName, description: editDesc, coverImage: coverPreview };
      groupService.updateGroup(updatedGroup);
      alert('Informações salvas com sucesso!');
  };

  const handleToggleSetting = (key: string) => {
      if (!group) return;
      const newSettings = { ...settings, [key]: !settings[key as keyof typeof settings] };
      setSettings(newSettings);

      // Persist immediately for settings
      if (key !== 'notifications') {
          const updatedGroup = {
              ...group,
              settings: {
                  ...group.settings,
                  [key]: newSettings[key as keyof typeof settings]
              }
          };
          groupService.updateGroup(updatedGroup);
      }
  };

  const handleRemoveMember = (memberId: string) => {
      if (!group) return;
      if(window.confirm('Remover este membro do grupo?')) {
          groupService.removeMember(group.id, memberId);
          setMembers(prev => prev.filter(m => m.id !== memberId));
      }
  };

  const handleLeaveGroup = () => {
      if(!id) return;
      let msg = 'Tem certeza que deseja sair do grupo?';
      
      if (isOwner) {
          msg = '⚠️ ATENÇÃO: Como você é o DONO, ao sair, a posse do grupo será transferida para um administrador ou membro aleatório. Deseja continuar?';
      }

      if(window.confirm(msg)) {
          groupService.leaveGroup(id);
          navigate('/groups');
      }
  };

  const handleDeleteGroup = () => {
      if(window.confirm('🔴 ATENÇÃO: Esta ação é irreversível. O grupo será apagado para todos os membros. Continuar?')) {
          if(id) groupService.deleteGroup(id);
          navigate('/groups');
      }
  };

  if (!group) return <div className="min-h-screen bg-[#0c0f14] flex items-center justify-center text-white">Carregando...</div>;

  const filteredMembers = members.filter(m => m.name.toLowerCase().includes(memberSearch.toLowerCase()));

  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top_left,_#0c0f14,_#0a0c10)] text-white font-['Inter'] flex flex-col overflow-hidden">
        <style>{`
            /* CSS Reset & Base */
            * { margin:0; padding:0; box-sizing:border-box; font-family:'Inter', sans-serif; }
            
            /* Header */
            header {
                display:flex; align-items:center; padding:16px;
                background: #0c0f14; position:fixed; width:100%; top:0; z-index:20;
                border-bottom:1px solid rgba(255,255,255,0.1); height: 65px;
            }
            header button { background:none; border:none; color:#00c2ff; font-size:20px; cursor:pointer; padding-right: 15px; transition: 0.2s; }
            header button:hover { color: #fff; }
            header h1 { font-size:18px; font-weight:600; color: #fff; }

            /* Tabs */
            .tabs-container {
                position: fixed; top: 65px; width: 100%; background: #0c0f14; z-index: 15;
                display: flex; border-bottom: 1px solid rgba(255,255,255,0.1); justify-content: space-around;
            }
            .tab-btn {
                padding: 14px 0; text-align: center; font-size: 13px; font-weight: 600; flex: 1;
                color: #888; cursor: pointer; transition: 0.3s; position: relative;
                background: none; border: none; text-transform: uppercase; letter-spacing: 0.5px;
            }
            .tab-btn.active { color: #00c2ff; }
            .tab-btn.active::after {
                content: ''; position: absolute; bottom: -1px; left: 20%; width: 60%; height: 3px; background: #00c2ff; border-radius: 3px 3px 0 0;
            }

            /* Main Content */
            main {
                padding-top: 130px; padding-bottom: 40px; width: 100%; max-width: 600px; 
                margin: 0 auto; padding-left: 20px; padding-right: 20px;
                overflow-y: auto; flex-grow: 1;
            }

            /* Cards & Inputs */
            .card {
                background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.05);
                border-radius: 16px; padding: 20px; margin-bottom: 20px;
            }
            
            .input-group { margin-bottom: 20px; }
            .input-label { font-size: 13px; color: #00c2ff; margin-bottom: 8px; display: block; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; }
            .input-field {
                width: 100%; background: #14171d; border: 1px solid rgba(255,255,255,0.1);
                border-radius: 10px; padding: 14px; color: #fff; font-size: 15px; outline: none;
                transition: border-color 0.2s;
            }
            .input-field:focus { border-color: #00c2ff; background: rgba(0,194,255,0.05); }
            textarea.input-field { resize: vertical; min-height: 100px; line-height: 1.5; }

            /* Cover Image */
            .cover-section {
                display: flex; flex-direction: column; align-items: center; margin-bottom: 25px;
            }
            .cover-wrapper {
                position: relative; width: 120px; height: 120px; margin-bottom: 15px; cursor: pointer;
            }
            .cover-img {
                width: 100%; height: 100%; object-fit: cover; border-radius: 50%;
                border: 3px solid #00c2ff; transition: 0.3s;
                box-shadow: 0 0 20px rgba(0,194,255,0.2);
            }
            .cover-wrapper:hover .cover-img { opacity: 0.8; }
            .cover-edit-badge {
                position: absolute; bottom: 5px; right: 5px; background: #00c2ff; color: #000;
                width: 32px; height: 32px; border-radius: 50%; display: flex; 
                align-items: center; justify-content: center; font-size: 14px;
                border: 2px solid #0c0f14; pointer-events: none;
            }
            .cover-text { font-size: 14px; color: #00c2ff; font-weight: 600; cursor: pointer; }

            /* Toggles (Regras) */
            .toggle-row {
                display: flex; align-items: center; justify-content: space-between;
                padding: 16px 0; border-bottom: 1px solid rgba(255,255,255,0.05);
            }
            .toggle-row:last-child { border-bottom: none; }
            .toggle-label h4 { font-size: 15px; font-weight: 500; color: #fff; margin-bottom: 4px; }
            .toggle-label p { font-size: 13px; color: #888; line-height: 1.3; }

            /* Switch */
            .switch { position: relative; display: inline-block; width: 46px; height: 26px; flex-shrink: 0; }
            .switch input { opacity: 0; width: 0; height: 0; }
            .slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: #333; transition: .4s; border-radius: 26px; }
            .slider:before { position: absolute; content: ""; height: 20px; width: 20px; left: 3px; bottom: 3px; background-color: white; transition: .4s; border-radius: 50%; }
            input:checked + .slider { background-color: #00c2ff; }
            input:checked + .slider:before { transform: translateX(20px); }

            /* Member List */
            .search-bar { margin-bottom: 20px; position: relative; }
            .search-bar i { position: absolute; left: 14px; top: 50%; transform: translateY(-50%); color: #666; font-size: 16px; }
            .search-bar input { padding-left: 40px; }

            .member-item {
                display: flex; align-items: center; padding: 12px; 
                background: rgba(255,255,255,0.02); border-radius: 10px;
                margin-bottom: 8px; border: 1px solid rgba(255,255,255,0.05);
            }
            .member-avatar {
                width: 44px; height: 44px; border-radius: 50%; background: #222;
                display: flex; align-items: center; justify-content: center; 
                margin-right: 15px; object-fit: cover; border: 2px solid #333;
            }
            .member-info { flex-grow: 1; }
            .member-name { font-size: 15px; font-weight: 600; color: #fff; }
            .member-role { font-size: 10px; font-weight: 700; color: #000; background: #00c2ff; padding: 2px 8px; border-radius: 10px; margin-left: 8px; display: inline-block; vertical-align: middle;}
            .member-role.admin { background: #FFD700; color: #000; }
            
            .btn-action {
                width: 32px; height: 32px; border-radius: 8px; font-size: 14px; cursor: pointer; border: none; transition: 0.2s;
                display: flex; align-items: center; justify-content: center;
            }
            .btn-remove { background: rgba(255, 77, 77, 0.1); color: #ff4d4d; }
            .btn-remove:hover { background: #ff4d4d; color: #fff; }

            /* Action Buttons */
            .action-link-card {
                display: flex; align-items: center; justify-content: space-between;
                padding: 18px; background: rgba(255,255,255,0.03); border-radius: 12px;
                border: 1px solid rgba(255,255,255,0.05); margin-bottom: 12px; cursor: pointer;
                transition: 0.2s;
            }
            .action-link-card:hover { background: rgba(255,255,255,0.06); border-color: #00c2ff; }
            .action-left { display: flex; align-items: center; gap: 15px; }
            .action-icon-box {
                width: 40px; height: 40px; background: rgba(0,194,255,0.1); border-radius: 10px;
                display: flex; align-items: center; justify-content: center; color: #00c2ff; font-size: 18px;
            }
            .action-text h4 { font-size: 15px; font-weight: 600; color: #fff; }
            .action-text p { font-size: 12px; color: #888; }

            /* Danger Zone */
            .danger-zone { margin-top: 30px; border-top: 1px solid rgba(255,77,77,0.2); padding-top: 20px; }
            .danger-title { color: #ff4d4d; font-size: 12px; font-weight: 700; text-transform: uppercase; margin-bottom: 15px; }
            
            .danger-btn {
                width: 100%; padding: 16px; background: rgba(255, 77, 77, 0.05);
                border: 1px solid rgba(255, 77, 77, 0.3); color: #ff4d4d;
                border-radius: 12px; font-weight: 600; cursor: pointer;
                display: flex; align-items: center; justify-content: center; gap: 10px;
                transition: 0.2s; margin-bottom: 10px;
            }
            .danger-btn:hover { background: rgba(255, 77, 77, 0.15); border-color: #ff4d4d; }

            .save-btn {
                width: 100%; padding: 16px; background: #00c2ff; color: #000;
                border: none; border-radius: 12px; font-weight: 700; font-size: 16px;
                cursor: pointer; transition: 0.3s; box-shadow: 0 4px 15px rgba(0,194,255,0.3);
            }
            .save-btn:hover { background: #0099cc; transform: translateY(-1px); }
            
            .section-header {
                font-size: 14px; font-weight: 700; color: #888; text-transform: uppercase; margin-bottom: 15px; padding-left: 5px;
            }
        `}</style>

        <header>
            <button onClick={handleBack}><i className="fa-solid fa-arrow-left"></i></button>
            <h1>Configurações</h1>
        </header>

        <div className="tabs-container">
            <button className={`tab-btn ${activeTab === 'info' ? 'active' : ''}`} onClick={() => setActiveTab('info')}>Info</button>
            <button className={`tab-btn ${activeTab === 'membros' ? 'active' : ''}`} onClick={() => setActiveTab('membros')}>Membros</button>
            <button className={`tab-btn ${activeTab === 'ajustes' ? 'active' : ''}`} onClick={() => setActiveTab('ajustes')}>Ajustes</button>
            <button className={`tab-btn ${activeTab === 'opcoes' ? 'active' : ''}`} onClick={() => setActiveTab('opcoes')}>Opções</button>
        </div>

        <main>
            {/* TAB: INFO (Geral) */}
            {activeTab === 'info' && (
                <div className="animate-fade-in">
                    {isOwner ? (
                        <div className="card">
                            <div className="cover-section">
                                <div className="cover-wrapper" onClick={() => document.getElementById('coverInput')?.click()}>
                                    {coverPreview ? (
                                        <img src={coverPreview} className="cover-img" alt="Cover" />
                                    ) : (
                                        <div className="cover-img" style={{background: '#1e2531', display:'flex', alignItems:'center', justifyContent:'center'}}>
                                            <i className="fa-solid fa-camera text-3xl text-gray-500"></i>
                                        </div>
                                    )}
                                    <div className="cover-edit-badge"><i className="fa-solid fa-pen"></i></div>
                                    <input type="file" id="coverInput" hidden accept="image/*" onChange={handleCoverChange} />
                                </div>
                                <span className="cover-text" onClick={() => document.getElementById('coverInput')?.click()}>Toque para editar capa</span>
                            </div>

                            <div className="input-group">
                                <label className="input-label">Nome do Grupo</label>
                                <input 
                                    type="text" 
                                    className="input-field" 
                                    value={editName} 
                                    onChange={(e) => setEditName(e.target.value)}
                                    placeholder="Ex: Comunidade Tech" 
                                />
                            </div>

                            <div className="input-group">
                                <label className="input-label">Descrição</label>
                                <textarea 
                                    className="input-field" 
                                    value={editDesc} 
                                    onChange={(e) => setEditDesc(e.target.value)}
                                    placeholder="Descreva o propósito do grupo..." 
                                />
                            </div>

                            <button className="save-btn" onClick={handleSaveGeneral}>Salvar Alterações</button>
                        </div>
                    ) : (
                        <div className="card" style={{textAlign:'center', padding: '40px 20px'}}>
                            <i className="fa-solid fa-lock text-4xl text-gray-700 mb-4"></i>
                            <p style={{color:'#aaa', fontSize: '15px'}}>Apenas administradores podem editar as informações principais.</p>
                        </div>
                    )}
                </div>
            )}

            {/* TAB: MEMBROS */}
            {activeTab === 'membros' && (
                <div className="animate-fade-in">
                    <div className="search-bar">
                        <i className="fa-solid fa-magnifying-glass"></i>
                        <input 
                            type="text" 
                            className="input-field" 
                            placeholder="Buscar membro..." 
                            value={memberSearch}
                            onChange={(e) => setMemberSearch(e.target.value)}
                        />
                    </div>
                    
                    <div className="section-header">
                        {filteredMembers.length} {filteredMembers.length === 1 ? 'Membro' : 'Membros'}
                    </div>

                    <div className="card" style={{padding: '10px'}}>
                        {filteredMembers.map(member => (
                            <div key={member.id} className="member-item">
                                {member.avatar ? (
                                    <img src={member.avatar} className="member-avatar" alt={member.name} />
                                ) : (
                                    <div className="member-avatar"><i className="fa-solid fa-user text-gray-500"></i></div>
                                )}
                                <div className="member-info">
                                    <div className="member-name">
                                        {member.name}
                                        {member.role === 'Dono' && <span className="member-role admin">Dono</span>}
                                        {member.role === 'Admin' && <span className="member-role">Admin</span>}
                                    </div>
                                </div>
                                {isOwner && !member.isMe && (
                                    <button className="btn-action btn-remove" onClick={() => handleRemoveMember(member.id)} title="Remover">
                                        <i className="fa-solid fa-user-minus"></i>
                                    </button>
                                )}
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {/* TAB: AJUSTES (Permissões) */}
            {activeTab === 'ajustes' && (
                <div className="animate-fade-in">
                    <div className="card">
                        <div className="toggle-row">
                            <div className="toggle-label">
                                <h4>Notificações</h4>
                                <p>Receber alertas de novas mensagens</p>
                            </div>
                            <label className="switch">
                                <input type="checkbox" checked={settings.notifications} onChange={() => handleToggleSetting('notifications')} />
                                <span className="slider"></span>
                            </label>
                        </div>

                        {isOwner && (
                            <>
                                <div className="toggle-row">
                                    <div className="toggle-label">
                                        <h4>Apenas Admins</h4>
                                        <p>Membros não podem enviar mensagens</p>
                                    </div>
                                    <label className="switch">
                                        <input type="checkbox" checked={settings.onlyAdminsPost} onChange={() => handleToggleSetting('onlyAdminsPost')} />
                                        <span className="slider"></span>
                                    </label>
                                </div>

                                <div className="toggle-row">
                                    <div className="toggle-label">
                                        <h4>Aprovar Membros</h4>
                                        <p>Solicitações exigem aprovação</p>
                                    </div>
                                    <label className="switch">
                                        <input type="checkbox" checked={settings.approveMembers} onChange={() => handleToggleSetting('approveMembers')} />
                                        <span className="slider"></span>
                                    </label>
                                </div>
                            </>
                        )}
                    </div>
                    
                    {isOwner && (
                        <div className="action-link-card" onClick={() => navigate(`/group-limits/${id}`)}>
                            <div className="action-left">
                                <div className="action-icon-box"><i className="fa-solid fa-sliders"></i></div>
                                <div className="action-text">
                                    <h4>Controles Avançados</h4>
                                    <p>Limites, modo lento e palavras proibidas</p>
                                </div>
                            </div>
                            <i className="fa-solid fa-chevron-right text-gray-500"></i>
                        </div>
                    )}
                </div>
            )}

            {/* TAB: OPÇÕES (Ações) */}
            {activeTab === 'opcoes' && (
                <div className="animate-fade-in">
                    
                    <div className="action-link-card" onClick={() => navigate(`/group-links/${id}`)}>
                        <div className="action-left">
                            <div className="action-icon-box"><i className="fa-solid fa-link"></i></div>
                            <div className="action-text">
                                <h4>Links de Convite</h4>
                                <p>Gerencie links de entrada e afiliados</p>
                            </div>
                        </div>
                        <i className="fa-solid fa-chevron-right text-gray-500"></i>
                    </div>

                    <div className="action-link-card" onClick={() => navigate(`/group-chat/${id}`)}>
                        <div className="action-left">
                            <div className="action-icon-box"><i className="fa-regular fa-comments"></i></div>
                            <div className="action-text">
                                <h4>Ir para o Chat</h4>
                                <p>Voltar para a conversa do grupo</p>
                            </div>
                        </div>
                        <i className="fa-solid fa-chevron-right text-gray-500"></i>
                    </div>

                    <div className="danger-zone">
                        <div className="danger-title">Zona de Perigo</div>
                        
                        <button className="danger-btn" onClick={handleLeaveGroup}>
                            <i className="fa-solid fa-arrow-right-from-bracket"></i> Sair do Grupo
                        </button>

                        {isOwner && (
                            <button className="danger-btn" style={{background:'rgba(255,0,0,0.1)', borderColor: '#ff0000', color: '#ff0000'}} onClick={handleDeleteGroup}>
                                <i className="fa-solid fa-trash"></i> Apagar Grupo Permanentemente
                            </button>
                        )}
                    </div>
                </div>
            )}
        </main>
    </div>
  );
};
