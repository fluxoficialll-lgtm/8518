import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.fluxplatform.app',
  appName: 'Flux Platform',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  },
  plugins: {
    // Configurações futuras de plugins nativos virão aqui
  }
};

export default config;