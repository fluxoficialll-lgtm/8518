
import { db } from '@/database';
import { ChatMessage, ChatData } from '../types';
import { recommendationService } from './recommendationService';
import { authService } from './authService';

// Re-export for consumers (pages)
export type { ChatMessage, ChatData };

// Start with empty chats. Real chats are created via interactions.
const INITIAL_CHATS: Record<string, ChatData> = {};

export const chatService = {
    getAllChats: (): Record<string, ChatData> => {
        const chats = db.chats.getAll();
        // Initialize with mock data if empty ONLY if specifically requested, otherwise return empty
        if (Object.keys(chats).length === 0 && !localStorage.getItem('app_chats_seeded')) {
            db.chats.saveAll(INITIAL_CHATS);
            localStorage.setItem('app_chats_seeded', 'true');
            return INITIAL_CHATS;
        }
        return chats;
    },

    // Helper to generate a consistent ID for private chats between two users
    getPrivateChatId: (email1: string, email2: string): string => {
        const sorted = [email1, email2].sort();
        return `${sorted[0]}_${sorted[1]}`;
    },

    getChat: (id: string): ChatData => {
        let chat = db.chats.get(id);
        if (!chat) {
            // Create new empty chat if not exists (lazy creation)
            chat = {
                id,
                contactName: 'Novo Chat', // Placeholder, resolved dynamically in UI
                isBlocked: false,
                messages: []
            };
            db.chats.set(chat);
        }
        return chat;
    },

    getUnreadCount: (): number => {
        const allChats = chatService.getAllChats();
        let count = 0;
        const currentUserEmail = authService.getCurrentUserEmail();
        
        if (!currentUserEmail) return 0;

        Object.values(allChats).forEach(chat => {
            const chatIdStr = chat.id.toString();
            
            // --- FIX: Ignore Group Chats for main badge ---
            if (!chatIdStr.includes('@')) return;

            // Only count if user is participant
            if (!chatIdStr.includes(currentUserEmail)) return;

            // LOGIC UPDATE: Count messages sent BY OTHERS that are NOT read
            const unreadInChat = chat.messages.filter(m => {
                if (m.senderEmail) {
                    return m.senderEmail !== currentUserEmail && m.status !== 'read';
                }
                // Fallback for legacy messages
                return m.type === 'received' && m.status !== 'read';
            }).length;
            
            count += unreadInChat;
        });
        return count;
    },

    // New method for Group specific unread counts
    getGroupUnreadCount: (groupId?: string): number => {
        const currentUserEmail = authService.getCurrentUserEmail();
        if (!currentUserEmail) return 0;
        
        const countFn = (chat: ChatData) => chat.messages.filter(m => {
             const isFromOther = m.senderEmail ? m.senderEmail !== currentUserEmail : m.type === 'received';
             return isFromOther && m.status !== 'read';
        }).length;

        if (groupId) {
            const chat = db.chats.get(groupId);
            return chat ? countFn(chat) : 0;
        }

        const allChats = db.chats.getAll();
        let total = 0;
        Object.values(allChats).forEach(chat => {
            // Group IDs do not have '@'
            if (!chat.id.toString().includes('@')) { 
                // In a real app we'd check membership here too, but generally only joined groups have chats in local DB context
                total += countFn(chat);
            }
        });
        return total;
    },

    getUnreadCountForChat: (chatId: string): number => {
        const chat = db.chats.get(chatId);
        const currentUserEmail = authService.getCurrentUserEmail();
        if (!chat || !currentUserEmail) return 0;
        
        return chat.messages.filter(m => {
            if (m.senderEmail) {
                return m.senderEmail !== currentUserEmail && m.status !== 'read';
            }
            return m.type === 'received' && m.status !== 'read';
        }).length;
    },

    markChatAsRead: (chatId: string) => {
        const chat = db.chats.get(chatId);
        const currentUserEmail = authService.getCurrentUserEmail();
        if (!chat || !currentUserEmail) return;

        let changed = false;
        const newMessages = chat.messages.map(m => {
            const isFromOther = m.senderEmail ? m.senderEmail !== currentUserEmail : m.type === 'received';
            if (isFromOther && m.status !== 'read') {
                changed = true;
                return { ...m, status: 'read' as const };
            }
            return m;
        });

        if (changed) {
            const updatedChat = { ...chat, messages: newMessages };
            db.chats.set(updatedChat);
        }
    },

    markAllAsRead: () => {
        const allChats = chatService.getAllChats();
        const currentUserEmail = authService.getCurrentUserEmail();
        if (!currentUserEmail) return;

        Object.values(allChats).forEach(chat => {
            const chatIdStr = chat.id.toString();
            
            // --- FIX: Ignore Group Chats for global 'mark all read' usually used in Messages tab ---
            if (!chatIdStr.includes('@')) return;

            // Check if user is part of this chat
            if (!chatIdStr.includes(currentUserEmail)) return;

            let changed = false;
            const newMessages = chat.messages.map(m => {
                const isFromOther = m.senderEmail ? m.senderEmail !== currentUserEmail : m.type === 'received';
                if (isFromOther && m.status !== 'read') {
                    changed = true;
                    return { ...m, status: 'read' as const };
                }
                return m;
            });

            if (changed) {
                const updatedChat = { ...chat, messages: newMessages };
                db.chats.set(updatedChat);
            }
        });
    },

    sendMessage: (chatId: string, message: ChatMessage) => {
        const chat = db.chats.get(chatId);
        let chatData = chat;

        if (!chatData) {
             chatData = {
                id: chatId,
                contactName: 'Chat',
                isBlocked: false,
                messages: []
            };
        }
        
        chatData.messages.push(message);
        db.chats.set(chatData);

        // --- ALGORITHM INTEGRATION ---
        if (message.type === 'sent' && message.contentType === 'text') {
            const email = authService.getCurrentUserEmail();
            if (email) {
                setTimeout(() => {
                    recommendationService.analyzeMessage(email, message.text);
                }, 100);
            }
        }
    },

    clearChat: (chatId: string) => {
        const chat = db.chats.get(chatId);
        if (chat) {
            chat.messages = [];
            db.chats.set(chat);
        }
    },

    deleteMessages: (chatId: string, messageIds: number[]) => {
        const chat = db.chats.get(chatId);
        if (chat) {
            chat.messages = chat.messages.filter(m => !messageIds.includes(m.id));
            db.chats.set(chat);
        }
    },

    toggleBlock: (chatId: string): boolean => {
        const chat = db.chats.get(chatId);
        if (chat) {
            chat.isBlocked = !chat.isBlocked;
            db.chats.set(chat);
            return chat.isBlocked;
        }
        return false;
    },

    toggleBlockByContactName: (contactName: string): boolean => {
        const chats = chatService.getAllChats();
        let chat = Object.values(chats).find(c => c.contactName === contactName);
        
        if (chat) {
            chat.isBlocked = !chat.isBlocked;
            db.chats.set(chat);
        } else {
            const newId = Date.now().toString();
            chat = {
                id: newId,
                contactName: contactName,
                isBlocked: true,
                messages: []
            };
            db.chats.set(chat);
        }
        
        return chat.isBlocked;
    },
    
    isUserBlocked: (contactName: string): boolean => {
        const chats = chatService.getAllChats();
        const chat = Object.values(chats).find(c => c.contactName === contactName);
        return chat ? chat.isBlocked : false;
    },

    hasBlockingRelationship: (currentUserEmail: string, targetIdentifier: string): boolean => {
        if (!currentUserEmail || !targetIdentifier) return false;
        let cleanTarget = targetIdentifier;
        if (cleanTarget.startsWith('@')) cleanTarget = cleanTarget.substring(1);

        let targetEmail = cleanTarget;
        if (!cleanTarget.includes('@') || !cleanTarget.includes('.')) {
             const user = authService.getUserByHandle(cleanTarget);
             if (user) targetEmail = user.email;
        }

        const chatId = chatService.getPrivateChatId(currentUserEmail, targetEmail);
        const chat = db.chats.get(chatId);
        if (chat && chat.isBlocked) return true;

        const allChats = db.chats.getAll();
        return Object.values(allChats).some(c => 
            c.isBlocked && 
            (c.contactName === cleanTarget || c.contactName === `@${cleanTarget}` || c.id === chatId)
        );
    },

    getBlockedIdentifiers: (currentUserEmail: string): Set<string> => {
        const blockedSet = new Set<string>();
        const allChats = db.chats.getAll();
        const allUsers = db.users.getAll();

        Object.values(allChats).forEach(chat => {
            if (chat.isBlocked) {
                const chatId = chat.id.toString();
                if (chatId.includes(currentUserEmail) && chatId.includes('_')) {
                    const parts = chatId.split('_');
                    const otherEmail = parts.find(p => p !== currentUserEmail);
                    if (otherEmail) {
                        blockedSet.add(otherEmail);
                        const user = allUsers[otherEmail];
                        if (user?.profile?.name) {
                            blockedSet.add(user.profile.name);
                            blockedSet.add(`@${user.profile.name}`);
                        }
                    }
                } 
                else if (chat.contactName) {
                    blockedSet.add(chat.contactName);
                    blockedSet.add(`@${chat.contactName}`);
                    const user = authService.getUserByHandle(chat.contactName);
                    if (user) blockedSet.add(user.email);
                }
            }
        });
        return blockedSet;
    }
};
