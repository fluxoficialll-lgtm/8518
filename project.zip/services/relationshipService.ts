
import { Relationship, User } from '../types';
import { authService } from './authService';
import { notificationService } from './notificationService';
import { db } from '@/database';

// Helper to simulate DB delay
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

const API_URL = '/api';

export const relationshipService = {
  getRelationships: (): Relationship[] => {
    return db.relationships.getAll();
  },

  followUser: async (targetUsername: string): Promise<'following' | 'requested'> => {
    // Retry Logic for Stability
    await delay(300);
    
    const currentUserEmail = authService.getCurrentUserEmail();
    
    // If no email in storage, user is definitely logged out
    if (!currentUserEmail) {
        throw new Error("Usuário não logado");
    }

    let currentUser = authService.getCurrentUser();
    
    // Robust check: If email exists but user object is missing, wait for DB initialization
    if (!currentUser) {
        let retries = 5; 
        while (!currentUser && retries > 0) {
            await delay(300);
            currentUser = authService.getCurrentUser();
            retries--;
        }
    }
    
    // Final check: Use fallback instead of throwing error to ensure UX continuity
    if (!currentUser) {
        console.warn("Follow Warning: Database failed to load user profile. Using fallback.");
        // Attempt direct DB fetch in case auth service cache is stale
        const dbUser = db.users.get(currentUserEmail);
        if (dbUser) {
            currentUser = dbUser;
        } else {
            // Construct minimal valid user object
            currentUser = {
                email: currentUserEmail,
                isVerified: true,
                isProfileCompleted: true,
                profile: {
                    name: currentUserEmail.split('@')[0],
                    nickname: 'Usuário',
                    isPrivate: false,
                    photoUrl: undefined
                }
            } as User;
        }
    }

    // Normalizar username (remover @)
    const targetClean = targetUsername.replace('@', '').toLowerCase();
    
    // Recuperar todos relacionamentos
    const rels = db.relationships.getAll();
    
    // Verificar se já existe
    const existing = rels.find(r => r.followerEmail === currentUserEmail && r.followingUsername === targetClean);
    if (existing) return existing.status === 'accepted' ? 'following' : 'requested';

    // Verificar privacidade do usuário alvo
    const allUsers = db.users.getAll();
    const targetUser = Object.values(allUsers).find(u => u.profile?.name === targetClean);
    
    // Se o perfil for Privado, status é 'pending' (Solictado). 
    // Se for Público (ou usuário não encontrado/mock), é 'accepted' (Seguindo).
    let status: 'accepted' | 'pending' = 'accepted';
    
    if (targetUser && targetUser.profile?.isPrivate) {
        status = 'pending';
    }

    const newRel: Relationship = {
        followerEmail: currentUserEmail,
        followingUsername: targetClean,
        status: status
    };

    db.relationships.add(newRel);

    // Trigger Notification
    if (targetUser) {
        notificationService.addNotification({
            type: status === 'accepted' ? 'follow' : 'pending',
            subtype: status === 'pending' ? 'friend' : undefined,
            username: currentUser.profile?.name || 'Alguém',
            avatar: currentUser.profile?.photoUrl || '',
            text: status === 'accepted' ? 'começou a te seguir.' : 'solicitou para te seguir.',
            recipientEmail: targetUser.email,
            isFollowing: true
        });
    }
    
    return status === 'accepted' ? 'following' : 'requested';
  },

  unfollowUser: async (targetUsername: string) => {
    await delay(200);
    const currentUserEmail = authService.getCurrentUserEmail();
    if (!currentUserEmail) return;
    
    const targetClean = targetUsername.replace('@', '').toLowerCase();
    db.relationships.remove(currentUserEmail, targetClean);
  },

  // New: Accept a follow request (Private Account Logic)
  acceptFollowRequest: async (followerHandle: string) => {
      const currentUser = authService.getCurrentUser();
      if (!currentUser || !currentUser.profile?.name) return;

      const myUsername = currentUser.profile.name.toLowerCase();
      const followerClean = followerHandle.replace('@', '').toLowerCase();
      const followerUser = authService.getUserByHandle(followerClean);
      
      if (!followerUser) return;

      const followerEmail = followerUser.email;

      // Find the relationship where they follow me
      const allRels = db.relationships.getAll();
      const rel = allRels.find(r => 
          r.followerEmail === followerEmail && 
          r.followingUsername === myUsername
      );

      if (rel) {
          // Update status to accepted (Unlock Profile)
          rel.status = 'accepted';
          db.relationships.add(rel);

          // Notify the follower (User 1)
          notificationService.addNotification({
              type: 'follow', 
              username: currentUser.profile.name, // Use handle so link works
              avatar: currentUser.profile.photoUrl || '',
              text: 'aceitou sua solicitação. Agora você pode ver o perfil.', // "Request Accepted" clearer message
              recipientEmail: followerEmail,
              isFollowing: true
          });
      }
  },

  // New: Reject a follow request
  rejectFollowRequest: async (followerHandle: string) => {
      const currentUser = authService.getCurrentUser();
      if (!currentUser || !currentUser.profile?.name) return;

      const myUsername = currentUser.profile.name.toLowerCase();
      const followerClean = followerHandle.replace('@', '').toLowerCase();
      const followerUser = authService.getUserByHandle(followerClean);
      
      if (!followerUser) return;
      
      const followerEmail = followerUser.email;

      // Remove the relationship completely
      db.relationships.remove(followerUser.email, myUsername);

      // Notify the follower (User 1) - Optional in some apps, but explicit here as requested
      notificationService.addNotification({
          type: 'follow',
          username: currentUser.profile.name, // Use handle for linking
          avatar: currentUser.profile.photoUrl || '',
          text: 'não aceitou sua solicitação de seguir.', // "Request Rejected"
          recipientEmail: followerEmail,
          isFollowing: false
      });
  },

  isFollowing: (targetUsername: string): 'none' | 'following' | 'requested' => {
    const currentUserEmail = authService.getCurrentUserEmail();
    if (!currentUserEmail) return 'none';
    
    const targetClean = targetUsername.replace('@', '').toLowerCase();
    const rels = db.relationships.getAll();
    
    const rel = rels.find(r => r.followerEmail === currentUserEmail && r.followingUsername === targetClean);
    
    if (!rel) return 'none';
    return rel.status === 'accepted' ? 'following' : 'requested';
  },

  // Retorna lista completa de SEGUIDORES (quem segue o username)
  getFollowers: (username: string): { name: string; username: string; avatar?: string }[] => {
    const cleanUsername = username.replace('@', '').toLowerCase();
    const rels = db.relationships.getAll();
    const allUsers = db.users.getAll(); // Record<email, User>

    // Find relationships where followingUsername == cleanUsername
    const followerEmails = rels
        .filter(r => r.followingUsername === cleanUsername && r.status === 'accepted')
        .map(r => r.followerEmail);

    // Map emails to user profiles
    const followers = followerEmails.map(email => {
        const user = allUsers[email];
        if (user && user.profile) {
            return {
                name: user.profile.nickname || user.profile.name,
                username: user.profile.name,
                avatar: user.profile.photoUrl
            };
        }
        // Fallback for deleted/unknown users
        return { name: 'Usuário', username: 'user', avatar: undefined };
    });

    return followers;
  },

  // Retorna lista completa de SEGUINDO (quem o email segue)
  getFollowing: (email: string): { name: string; username: string; avatar?: string }[] => {
    const rels = db.relationships.getAll();
    const allUsers = db.users.getAll();

    // Find relationships where followerEmail == email
    const followingUsernames = rels
        .filter(r => r.followerEmail === email && r.status === 'accepted')
        .map(r => r.followingUsername);

    // Need to find user objects for these usernames
    const following: { name: string; username: string; avatar?: string }[] = [];
    const usersArray = Object.values(allUsers);

    followingUsernames.forEach(targetUsername => {
        const user = usersArray.find(u => u.profile?.name === targetUsername);
        if (user && user.profile) {
            following.push({
                name: user.profile.nickname || user.profile.name,
                username: user.profile.name,
                avatar: user.profile.photoUrl
            });
        } else {
            // Fallback if user not found in DB (e.g. external/mock data)
            following.push({
                name: targetUsername,
                username: targetUsername,
                avatar: undefined
            });
        }
    });

    return following;
  },

  // Retorna usuários que eu sigo E que me seguem (Real Logic)
  getMutualFriends: async (): Promise<{id: number | string, name: string, username: string, avatar: string}[]> => {
    const currentUserEmail = authService.getCurrentUserEmail();
    if (!currentUserEmail) return [];

    const users = db.users.getAll();
    const myProfile = users[currentUserEmail];
    const myUsername = myProfile?.profile?.name?.toLowerCase();

    if (!myUsername) return [];

    const rels = db.relationships.getAll();

    // 1. Quem eu sigo (usernames)
    const iFollowUsernames = rels
        .filter(r => r.followerEmail === currentUserEmail && r.status === 'accepted')
        .map(r => r.followingUsername);

    // 2. Quem me segue (emails)
    const usersFollowingMeEmails = rels
        .filter(r => r.followingUsername === myUsername && r.status === 'accepted')
        .map(r => r.followerEmail);

    // 3. Interseção
    const mutuals: any[] = [];
    const usersArray = Object.values(users);

    // Check each user I follow
    for (const targetUsername of iFollowUsernames) {
        // Find the user object for this username to get their email
        const targetUserEntry = usersArray.find(u => u.profile?.name === targetUsername);
        
        if (targetUserEntry) {
            // If this user's email is in the list of people who follow me
            if (usersFollowingMeEmails.includes(targetUserEntry.email)) {
                mutuals.push({
                    id: targetUserEntry.email, // Use email as unique ID
                    name: targetUserEntry.profile?.nickname || targetUserEntry.profile?.name || 'User',
                    username: targetUserEntry.profile?.name || '',
                    avatar: targetUserEntry.profile?.photoUrl || ''
                });
            }
        }
    }

    return mutuals;
  },

  // NEW: Server-Side Leaderboard (Scalable)
  getTopCreators: async (): Promise<(User & { followerCount: number })[]> => {
      try {
          const response = await fetch(`${API_URL}/rankings/top`);
          if (response.ok) {
              const result = await response.json();
              return result.data || [];
          }
      } catch (e) {
          console.warn("Using local ranking fallback");
      }

      // Fallback Local Logic (Not scalable but keeps app working without backend)
      const allUsers = db.users.getAll();
      const allRels = db.relationships.getAll();
      
      const followerCounts: Record<string, number> = {};
      allRels.forEach(rel => {
          if (rel.status === 'accepted') {
              const t = rel.followingUsername.toLowerCase();
              followerCounts[t] = (followerCounts[t] || 0) + 1;
          }
      });

      return Object.values(allUsers).map(u => ({
          ...u,
          followerCount: followerCounts[u.profile?.name.toLowerCase() || ''] || 0
      })).sort((a, b) => b.followerCount - a.followerCount).slice(0, 20);
  }
};
