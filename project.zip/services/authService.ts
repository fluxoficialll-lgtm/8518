
import { User, AuthError, VerificationSession, PaymentProviderConfig, UserProfile, NotificationSettings, SecuritySettings, UserSession } from '../types';
import { emailService } from './emailService';
import { cryptoService } from './cryptoService';

// API Configuration
const API_URL = '/api/auth';
const API_USERS = '/api/users';

export const authService = {
  isValidEmail: (email: string) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  },

  // === GLOBAL LOGIN ===
  login: async (email: string, password: string): Promise<{ user: User; nextStep: string }> => {
    try {
        const hashedPassword = await cryptoService.hashPassword(password);
        
        const response = await fetch(`${API_URL}/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password: hashedPassword })
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.error || AuthError.WRONG_PASSWORD);
        }

        // Store Session globally
        localStorage.setItem('auth_token', data.token);
        localStorage.setItem('user_email', data.user.email);
        
        // Cache user profile locally for quick access, but verify with server later
        localStorage.setItem('cached_user_profile', JSON.stringify(data.user));

        if (!data.user.isProfileCompleted) return { user: data.user, nextStep: '/complete-profile' };
        return { user: data.user, nextStep: '/feed' };

    } catch (e: any) {
        throw new Error(e.message || AuthError.GENERIC);
    }
  },

  // === GLOBAL REGISTER ===
  register: async (email: string, password: string) => {
    try {
        // Step 1: Pre-validation (optional check if exists via API)
        // For now, we trust the final register call to fail if duplicate.
        
        const hashedPassword = await cryptoService.hashPassword(password);
        
        // Store temp data locally until verification
        sessionStorage.setItem('temp_register_email', email);
        sessionStorage.setItem('temp_register_pw', hashedPassword);
        
        // Send code via email
        await authService.sendVerificationCode(email);

    } catch (e: any) {
        throw new Error(e.message || AuthError.GENERIC);
    }
  },

  // === VERIFY & CREATE USER ON SERVER ===
  verifyCode: async (email: string, code: string, isResetFlow: boolean = false) => {
    // 1. Verify code logic (Mocked locally for codes, but finalizing on server)
    const sessionStr = localStorage.getItem(`verify_${email}`);
    const session = sessionStr ? JSON.parse(sessionStr) : null;
    
    if (!session) throw new Error(AuthError.CODE_EXPIRED);
    if (Date.now() > session.expiresAt) throw new Error(AuthError.CODE_EXPIRED);
    if (session.code !== code) throw new Error(AuthError.CODE_INVALID);

    if (!isResetFlow) {
        // 2. Actually create the user on the server now
        const passwordHash = sessionStorage.getItem('temp_register_pw');
        if (!passwordHash) throw new Error("Erro de sessão. Tente registrar novamente.");

        const newUserPayload = {
            email,
            password: passwordHash,
            profile: {
                name: email.split('@')[0].toLowerCase(), // Temporary handle
                nickname: 'Novo Usuário',
                isPrivate: false
            }
        };

        const response = await fetch(`${API_URL}/register`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(newUserPayload)
        });

        const data = await response.json();
        if (!response.ok) throw new Error(data.error);

        // Auto login
        localStorage.setItem('user_email', email);
        localStorage.setItem('auth_token', 'temp_token_after_reg'); // In real app, server returns token
        
        sessionStorage.removeItem('temp_register_email');
        sessionStorage.removeItem('temp_register_pw');
    }
    
    return true;
  },

  sendVerificationCode: async (email: string, type: 'register' | 'reset' = 'register') => {
    // Generates code locally for the demo flow, but in prod this hits an endpoint
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    
    // Save locally to verify next step
    const session = {
        code,
        expiresAt: Date.now() + 5 * 60 * 1000,
        attempts: 0
    };
    localStorage.setItem(`verify_${email}`, JSON.stringify(session));

    // In a real app, we call the API to send email
    // await fetch('/api/send-email', ...)
    // For demo:
    alert(`[Flux Global] Seu código de verificação é: ${code}`);
  },

  // === GLOBAL PROFILE SYNC ===
  completeProfile: async (email: string, data: UserProfile) => {
      // Send update to server
      const response = await fetch(`${API_USERS}/update`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
              email,
              updates: {
                  profile: data,
                  isProfileCompleted: true
              }
          })
      });
      
      const res = await response.json();
      if (!response.ok) throw new Error(res.error);
      
      // Update local cache
      localStorage.setItem('cached_user_profile', JSON.stringify(res.user));
  },

  checkUsernameAvailability: async (username: string): Promise<boolean> => {
      // In real app: call API
      const response = await fetch(`${API_USERS}/search?q=${username}`);
      const users = await response.json();
      return !users.some((u: any) => u.profile?.name === username);
  },

  getCurrentUserEmail: () => localStorage.getItem('user_email'),
  
  getCurrentUser: (): User | null => {
    const cached = localStorage.getItem('cached_user_profile');
    return cached ? JSON.parse(cached) : null;
  },

  getAllUsers: (): User[] => {
      // This is now discouraged for global apps. Use search instead.
      return [];
  },

  searchUsers: async (query: string): Promise<User[]> => {
      const response = await fetch(`${API_USERS}/search?q=${query}`);
      return await response.json();
  },

  getUserByHandle: (handle: string): User | undefined => {
      // In a real app, this would be an async fetch. 
      // For this transition, we might need to rely on search or cache.
      // We will make it "best effort" via search API in components usually.
      return undefined; // Components should fetch async
  },
  
  logout: () => {
    localStorage.removeItem('user_email');
    localStorage.removeItem('auth_token');
    localStorage.removeItem('cached_user_profile');
  },

  // Placeholders for features that would require more backend logic
  updatePaymentConfig: async (config: PaymentProviderConfig) => {},
  updateNotificationSettings: (settings: NotificationSettings) => {},
  updateSecuritySettings: (settings: SecuritySettings) => {},
  updateHeartbeat: () => {},
  getUserSessions: () => [],
  revokeOtherSessions: async () => {},
  resetPassword: async (email: string, newPass: string) => {},
  changePassword: async (currentPass: string, newPass: string) => {},
  loginWithGoogle: async (): Promise<{ user: User; nextStep: string }> => {
      return { user: {} as User, nextStep: '/feed' };
  }
};
