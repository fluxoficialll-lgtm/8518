
import { Group, GroupLink, User } from '../types';
import { authService } from './authService';

const API_URL = '/api/groups';

export const groupService = {
  getGroups: async (): Promise<Group[]> => {
    const response = await fetch(API_URL);
    const data = await response.json();
    return data.data || [];
  },

  getGroupsSync: (): Group[] => {
      // Fallback for components demanding sync return. 
      // In real app, components should be refactored to use async/hooks.
      // This will return empty initially.
      return [];
  },

  getAllGroupsForRanking: async (): Promise<Group[]> => {
      const response = await fetch(`${API_URL}/top`);
      const data = await response.json();
      return data.data || [];
  },

  createGroup: async (group: Group) => {
    await fetch(`${API_URL}/create`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(group)
    });
    return true;
  },

  // Placeholders for detailed group logic (requires detailed endpoints)
  getGroupById: (id: string): Group | undefined => undefined,
  updateGroup: async (g: Group) => {},
  deleteGroup: (id: string) => {},
  joinGroup: (id: string) => 'joined',
  joinGroupByLinkCode: (c: string): { success: boolean; message: string; groupId?: string } => ({ success: false, message: '' }),
  leaveGroup: (id: string) => {},
  removeMember: (gid: string, email: string) => {},
  banMember: (gid: string, email: string) => {},
  promoteMember: (gid: string, email: string) => {},
  demoteMember: (gid: string, email: string) => {},
  getGroupMembers: (gid: string): User[] => [],
  getPendingMembers: (gid: string): User[] => [],
  approveMember: (gid: string, email: string) => {},
  rejectMember: (gid: string, email: string) => {},
  addGroupLink: (gid: string, name: string, maxUses?: number, expiresAt?: string) => null,
  removeGroupLink: (gid: string, lid: string) => {}
};
