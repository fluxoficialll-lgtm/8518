
export const contentSafetyService = {
    // Lista de palavras-chave para detecção (Exemplo simplificado)
    // Em produção, isso seria uma API de NLP ou uma lista muito mais extensa/obscurecida
    explicitKeywords: [
        'nude', 'sexo', 'porn', 'xxx', 'onlyfans', 'privacy', 'hot', 'sensual', 
        'adulto', '18+', '+18', 'proibido', 'safada', 'safado', 'novinha', 
        'amador', 'casal', 'intimo', 'vazou', 'pack'
    ],

    /**
     * Analisa o texto e (simbolicamente) a mídia para determinar se é +18.
     */
    analyzeContent: async (text: string, mediaFiles: any[]): Promise<{ isAdult: boolean; reason?: string }> => {
        const lowerText = text.toLowerCase();
        
        // 1. Análise de Texto (Keywords)
        for (const word of contentSafetyService.explicitKeywords) {
            // Verifica palavra exata ou contida de forma suspeita
            if (lowerText.includes(word)) {
                return { isAdult: true, reason: `Palavra suspeita detectada: "${word}"` };
            }
        }

        // 2. Simulação de Análise de Imagem (Computer Vision Mock)
        // Na vida real, aqui chamaríamos Google Cloud Vision ou AWS Rekognition
        if (mediaFiles.length > 0) {
            // Simulação: Se o nome do arquivo contiver termos explícitos (comum em uploads)
            // ou aleatoriamente para simular a IA detectando pele/nudez em 5% dos casos neste demo
            const randomCheck = Math.random() < 0.05; // 5% de chance de falso positivo/detecção simulada
            if (randomCheck) {
                return { isAdult: true, reason: "IA de visão computacional detectou nudez potencial." };
            }
        }

        return { isAdult: false };
    }
};
