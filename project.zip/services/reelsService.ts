
import { Post, Comment } from '../types';
import { db } from '@/database';
import { recommendationService } from './recommendationService';
import { postService } from './postService';
import { chatService } from './chatService';
import { authService } from './authService';
import { adService } from './adService';

export const reelsService = {
  /**
   * Retrieves only posts of type 'video' (Reels).
   * Applies AI recommendation algorithm and Adult Content Filtering.
   * NOW 100% REAL DATA - NO SEEDS.
   */
  getReels: (userEmail?: string, allowAdultContent: boolean = false): Post[] => {
    const allPosts = db.posts.getAll();
    // Filter specifically for video type
    let videos = allPosts.filter(p => p.type === 'video');

    // Filter Adult Content if setting is disabled
    if (!allowAdultContent) {
        videos = videos.filter(p => !p.isAdultContent);
    }

    // --- BLOCKING FILTER (BILATERAL) ---
    if (userEmail) {
        const blockedIds = chatService.getBlockedIdentifiers(userEmail);
        if (blockedIds.size > 0) {
            videos = videos.filter(p => {
                const handle = p.username.replace('@', '');
                return !blockedIds.has(p.username) && !blockedIds.has(handle);
            });
        }
    }

    // AI Algorithm Integration (Always Active)
    let sortedVideos: Post[] = [];
    if (userEmail && videos.length > 0) {
        sortedVideos = recommendationService.getRecommendedReels(videos, userEmail);
    } else {
        // Guest Mode or Fallback: Chronological reverse (Newest first)
        sortedVideos = videos.sort((a, b) => b.timestamp - a.timestamp);
    }

    // --- AD INJECTION ---
    const activeAds = adService.getAdsForPlacement('reels') as Post[];
    if (activeAds.length > 0) {
        const injectedReels: Post[] = [];
        sortedVideos.forEach((reel, index) => {
            injectedReels.push(reel);
            // Inject ad every 4 reels
            if ((index + 1) % 4 === 0) {
                const randomAd = activeAds[Math.floor(Math.random() * activeAds.length)];
                // Avoid immediate duplicate
                if(!injectedReels.find(p => p.id === randomAd.id)) {
                    injectedReels.push(randomAd);
                }
            }
        });
        return injectedReels;
    }

    return sortedVideos;
  },

  // Wrapper para upload de video
  uploadVideo: async (file: File): Promise<string> => {
      // Utiliza o serviço de postagem para converter mídia em Base64/Blob real
      return postService.uploadMedia(file);
  },

  /**
   * Adds a new Reel (video post) to the global storage.
   */
  addReel: (reel: Post) => {
    // Ensure strictly typed as video
    const newReel = { ...reel, type: 'video' as const };

    // --- DUPLICATE VIDEO CHECK ---
    const allPosts = db.posts.getAll();
    const isDuplicate = allPosts.some(existing => {
        // Check if video data matches exactly (Base64 or URL)
        if (existing.type === 'video' && existing.video && existing.video === newReel.video) {
            return true;
        }
        return false;
    });

    if (isDuplicate) {
        // Prevent duplicate upload spam
        return;
    }

    postService.addPost(newReel);
  },

  /**
   * Toggles like on a Reel.
   */
  toggleLike: async (reelId: string): Promise<Post | undefined> => {
    // Ad Logic
    if (reelId.startsWith('ad_')) {
        return await postService.toggleLike(reelId);
    }

    const post = db.posts.findById(reelId);

    if (post) {
      const newLiked = !post.liked;
      const updatedPost = {
        ...post,
        liked: newLiked,
        likes: post.likes + (newLiked ? 1 : -1)
      };
      
      db.posts.update(updatedPost);
      return updatedPost;
    }
    return undefined;
  },

  /**
   * Increments the view count for a Reel (Unique per user).
   */
  incrementView: (reelId: string, userEmail?: string) => {
    // Delegate to postService which handles unique view logic
    postService.incrementView(reelId, userEmail);
    // Track session impression for frequency limiting algorithm
    recommendationService.trackImpression(reelId);
  },

  /**
   * Get a specific reel by ID
   */
  getReelById: (id: string): Post | undefined => {
    if (id.startsWith('ad_')) {
        return postService.getPostById(id);
    }
    const reels = reelsService.getReels();
    return reels.find(r => r.id === id);
  }
};
