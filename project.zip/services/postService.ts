
import { Post, Comment, PaginatedResponse } from '../types';
import { authService } from './authService';

const API_URL = '/api/posts';

export const postService = {
  getFeedPaginated: async (options: { limit: number; cursor?: number | string; allowedTypes?: string[]; locationFilter?: string | null; allowAdultContent?: boolean }): Promise<PaginatedResponse<Post>> => {
    try {
        const userEmail = authService.getCurrentUserEmail();
        const cursorNum = typeof options.cursor === 'number' ? options.cursor : Date.now();
        
        // Fetch Global Feed from Server
        const response = await fetch(`${API_URL}?limit=${options.limit}&cursor=${cursorNum}&viewer=${userEmail || ''}`);
        const data = await response.json();
        
        let fetchedPosts: Post[] = data.data || [];

        // Client-side filtering (optimization: move to server query params in future)
        if (options.allowedTypes) {
            fetchedPosts = fetchedPosts.filter(p => options.allowedTypes!.includes(p.type));
        }
        
        if (options.locationFilter) {
            fetchedPosts = fetchedPosts.filter(p => p.location && p.location.includes(options.locationFilter!));
        }

        return { data: fetchedPosts, nextCursor: data.nextCursor };

    } catch (e) {
        console.error("Feed Error:", e);
        return { data: [], nextCursor: undefined };
    }
  },

  uploadMedia: async (file: File): Promise<string> => {
      const formData = new FormData();
      formData.append('file', file);

      try {
          const response = await fetch(`/api/upload`, {
              method: 'POST',
              body: formData
          });

          if (response.ok) {
              const data = await response.json();
              if (data.files && data.files.length > 0) {
                  return data.files[0].url; 
              }
          }
          throw new Error("Falha no upload");
      } catch (e) {
          console.error("Upload falhou", e);
          return "";
      }
  },

  addPost: async (post: Post) => {
    try {
        await fetch(`${API_URL}/create`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(post)
        });
    } catch (e) {
        console.error("Erro ao publicar post:", e);
    }
  },

  toggleLike: async (postId: string): Promise<Post | undefined> => {
    const userEmail = authService.getCurrentUserEmail();
    if (!userEmail) return undefined;

    try {
        const response = await fetch(`${API_URL}/like`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ postId, userEmail })
        });
        const data = await response.json();
        return data.post;
    } catch (e) {
        return undefined;
    }
  },

  addComment: async (postId: string, commentText: string, username: string, avatar?: string): Promise<Comment | undefined> => {
    try {
        const newComment: Comment = {
            id: Date.now().toString(),
            username, 
            text: commentText, 
            avatar, 
            timestamp: Date.now(), 
            likes: 0, 
            likedByMe: false, 
            replies: []
        };

        const response = await fetch(`${API_URL}/comment`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ postId, comment: newComment })
        });
        
        return newComment;
    } catch (e) {
        return undefined;
    }
  },

  // Helpers that might require server endpoints in full implementation
  getPostById: (id: string): Post | undefined => undefined,
  getUserPosts: (username: string): Post[] => [],
  deletePost: async (postId: string) => {},
  incrementView: (postId: string, userEmail?: string) => {},
  addReply: (postId: string, parentId: string, text: string, u: string, a?: string) => undefined,
  toggleCommentLike: (p: string, c: string) => false
};
