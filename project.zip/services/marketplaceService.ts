
import { MarketplaceItem, Comment, User } from '../types';
import { db } from '@/database';
import { adService } from './adService';

// --- ALGORITHM CONFIGURATION (Marketplace) ---
// Calibrado para corresponder à escala do RecommendationService (Feed)
const WEIGHTS = {
    AD_BOOST: 15000,         // Equalizado com o Hot Lead Bonus do Feed (Alta Prioridade)
    CATEGORY_AFFINITY: 800,  // Aumentado: Se o usuário gosta da categoria, mostra mais
    LOCATION_MATCH: 3000,    // Aumentado: Hiperlocalização é chave para conversão
    POPULARITY_MULTIPLIER: 50, 
    FRESHNESS_DECAY: 1.2     // Decaimento lento (Produtos duram mais que posts)
};

// Session-based User Profile (In a real app, this would be in Redis/DB)
interface UserInterestProfile {
    categoryHits: Record<string, number>;
    topLocation: string | null;
    locationHits: Record<string, number>;
}

const userProfiles: Record<string, UserInterestProfile> = {};

const getProfile = (email: string): UserInterestProfile => {
    if (!userProfiles[email]) {
        userProfiles[email] = { categoryHits: {}, topLocation: null, locationHits: {} };
    }
    return userProfiles[email];
};

const calculateScore = (item: MarketplaceItem, email?: string): number => {
    let score = 1000; // Base score
    const now = Date.now();

    // 1. Paid Content Boost (Business Priority)
    if (item.isAd) {
        score += WEIGHTS.AD_BOOST;
    }

    // 2. Popularity / Social Proof
    if (item.soldCount) {
        score += (item.soldCount * WEIGHTS.POPULARITY_MULTIPLIER);
    }

    // 3. Freshness (Decay Suave)
    const hoursOld = (now - item.timestamp) / (1000 * 60 * 60);
    score -= (hoursOld * 20); 

    // 4. Personalization (If user is logged in)
    if (email) {
        const profile = getProfile(email);

        // Category Affinity
        const catHits = profile.categoryHits[item.category] || 0;
        score += (catHits * WEIGHTS.CATEGORY_AFFINITY);

        // Location Match
        const locHits = profile.locationHits[item.location] || 0;
        
        // Se bate com a localização principal do usuário
        if (locHits > 0 || (profile.topLocation && item.location.includes(profile.topLocation))) {
            score += WEIGHTS.LOCATION_MATCH;
        }
    }

    return score;
};

export const marketplaceService = {
  /**
   * Returns items sorted by the Intelligent Delivery Algorithm
   */
  getRecommendedItems: (userEmail?: string): MarketplaceItem[] => {
    const allItems = db.marketplace.getAll();
    
    // Calculate score for organic items
    const scoredItems = allItems.map(item => ({
        item,
        score: calculateScore(item, userEmail)
    }));

    // Sort by Score Descending
    scoredItems.sort((a, b) => b.score - a.score);
    
    const sortedOrganic = scoredItems.map(x => x.item);

    // --- AD INJECTION ---
    const activeAds = adService.getAdsForPlacement('marketplace') as MarketplaceItem[];
    
    if (activeAds.length > 0) {
        const finalFeed: MarketplaceItem[] = [];
        sortedOrganic.forEach((item, index) => {
            finalFeed.push(item);
            // Inject ad every 5 items (Increased frequency for marketplace)
            if ((index + 1) % 5 === 0) {
                const randomAd = activeAds[Math.floor(Math.random() * activeAds.length)];
                // Avoid duplicates
                if (!finalFeed.find(i => i.id === randomAd.id)) {
                    finalFeed.push(randomAd);
                }
            }
        });
        return finalFeed;
    }

    return sortedOrganic;
  },

  getItems: (): MarketplaceItem[] => {
    return db.marketplace.getAll().sort((a, b) => b.timestamp - a.timestamp);
  },

  getItemById: (id: string): MarketplaceItem | undefined => {
    // Check if Ad
    if (id.startsWith('ad_')) {
        const campaignId = id.replace('ad_', '');
        const allAds = adService.getAdsForPlacement('marketplace') as MarketplaceItem[];
        return allAds.find(i => i.adCampaignId === campaignId);
    }

    const all = db.marketplace.getAll();
    return all.find(item => item.id === id);
  },
  
  createItem: (item: MarketplaceItem) => {
    db.marketplace.add(item);
  },
  
  deleteItem: (id: string) => {
    db.marketplace.delete(id);
  },

  /**
   * Records user interaction to train the algorithm for the current session
   */
  trackView: (item: MarketplaceItem, userEmail: string) => {
      // Track ad metric if it's an ad
      if (item.isAd && item.adCampaignId) {
          adService.trackMetric(item.adCampaignId, 'click');
      }

      const profile = getProfile(userEmail);
      
      // Boost Category
      profile.categoryHits[item.category] = (profile.categoryHits[item.category] || 0) + 1;
      
      // Boost Location
      if (item.location) {
          profile.locationHits[item.location] = (profile.locationHits[item.location] || 0) + 1;
          // Update top location if needed
          if (!profile.topLocation || profile.locationHits[item.location] > profile.locationHits[profile.topLocation]) {
              profile.topLocation = item.location;
          }
      }
  },

  addComment: (itemId: string, text: string, user: User): Comment | undefined => {
      if (itemId.startsWith('ad_')) return undefined;

      const all = db.marketplace.getAll();
      const itemIndex = all.findIndex(i => i.id === itemId);
      
      if (itemIndex > -1) {
          const item = all[itemIndex];
          
          const newComment: Comment = {
              id: Date.now().toString(),
              text: text,
              username: user.profile?.name || 'Usuário',
              avatar: user.profile?.photoUrl,
              timestamp: Date.now(),
              likes: 0
          };

          item.comments = [...(item.comments || []), newComment];
          
          db.marketplace.add(item); 
          return newComment;
      }
      return undefined;
  }
};
