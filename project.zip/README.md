
<div align="center">
<img width="1200" height="475" alt="Flux Platform" src="https://github.com/user-attachments/assets/0aa67016-6eaf-458a-adb2-6e31a0763ed6" />
</div>

# Flux Platform (Scalable Architecture)

Aplicação Full-Stack pronta para escala Enterprise (100k+ usuários), utilizando React (Frontend) e Node.js Cluster (Backend).

---

## 📱 Guia: Transformar em APK (Android)

Para gerar o aplicativo Android instalável, siga os passos abaixo. Você precisará ter o **Android Studio** instalado no seu computador.

### 1. Preparação
Instale as dependências do projeto e do Capacitor:
```bash
npm install
```

### 2. Inicialização do Ambiente Mobile
Execute este comando apenas na primeira vez para criar a pasta `android`:
```bash
npm run mobile:android
```

### 3. Sincronizar Código
Sempre que você fizer alterações no código React, rode este comando para atualizar o projeto Android:
```bash
npm run mobile:build
```

### 4. Gerar o APK
Abra o Android Studio através do comando:
```bash
npm run mobile:open
```
1. No Android Studio, aguarde o Gradle sincronizar.
2. Vá em **Build** > **Build Bundle(s) / APK(s)** > **Build APK(s)**.
3. O arquivo `.apk` será gerado na pasta de saída (geralmente `android/app/build/outputs/apk/debug/`).

---

## 🚀 Guia de Produção: Conectando os Fios (100k Usuários)

Para sair do modo de desenvolvimento (Docker Local) e ir para produção real, você precisa criar contas nos serviços abaixo e adicionar as chaves no seu arquivo `.env`.

### 1. Banco de Dados & Infraestrutura (Onde os dados vivem)

| Serviço | Função | Site para Criar Conta | Variável no .env |
| :--- | :--- | :--- | :--- |
| **Supabase** (ou AWS RDS) | Banco de Dados Principal (Usuários, Financeiro) | [supabase.com](https://supabase.com) | `DATABASE_URL` |
| **ScyllaDB Cloud** | Banco de Alta Velocidade (Feed, Posts, Analytics) | [scylladb.com](https://www.scylladb.com/scylla-cloud/) | `SCYLLA_HOST` |
| **Upstash** (ou Redis Cloud) | Sessões, Cache e Status Online | [upstash.com](https://upstash.com) | `REDIS_URL` |

### 2. Integrações de Terceiros (APIs Externas)

| Serviço | Função | Site para Criar Conta | Variável no .env |
| :--- | :--- | :--- | :--- |
| **Google Cloud** | Login Social com Google | [console.cloud.google.com](https://console.cloud.google.com) | `GOOGLE_CLIENT_ID` <br> `GOOGLE_CLIENT_SECRET` |
| **Pagamentos** | Processamento PIX (Gateway) | [mercadopago.com.br/developers](https://www.mercadopago.com.br/developers) | *Configurado via UI do Admin* |

### 3. Armazenamento de Arquivos (Mídia)

*Atualmente, o sistema salva em disco local. Para 100k usuários, recomenda-se configurar um Bucket S3.*
* **Site:** [AWS S3](https://aws.amazon.com/s3) ou [Cloudinary](https://cloudinary.com)

---

## ⚡ Guia Rápido: Como Rodar Localmente

### 1. Instalação
Abra o terminal na pasta do projeto e instale as dependências:
```bash
npm install
```

### 2. Escolha o Modo de Uso

#### A) Modo Produção Local (Recomendado para testes reais)
Isso compila o React e inicia o servidor Node.js real. É exatamente assim que rodará no servidor.
```bash
npm run test:public
```
*Acesse: http://localhost:3000*

#### B) Infraestrutura Completa (Docker)
Se você quiser ligar os bancos de dados reais (Postgres, ScyllaDB, Redis) para testar a capacidade de escala:
```bash
npm run db:up
```
*O sistema detectará automaticamente que os bancos estão online e parará de usar os mocks em memória.*

---

## ☁️ Deploy em Nuvem (Render/Railway)

1. Crie um novo Web Service no seu provedor de Cloud.
2. Adicione as **Variáveis de Ambiente** listadas acima na aba "Environment".
3. Use as seguintes configurações:
   - **Build Command:** `npm install && npm run build`
   - **Start Command:** `npm start`

---

## 🔧 Estrutura de Pastas

- `/src`: Código fonte do React (Frontend).
- `/server.js`: Servidor Node.js (API Gateway + Arquivos Estáticos).
- `/backend`: Lógica de conexão com bancos de dados.
- `/services`: Lógica de negócios compartilhada.
